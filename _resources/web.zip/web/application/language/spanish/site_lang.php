<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:        Spanish site
* Author:      biTTia (dominios@bittia.com)
* Description: Textos web
*/

// Genérico
$lang['comun.titulo']  = 'Portal de venta de unidades productivas';
// Navbar
$lang['navbar.titulo'] = 'Portal de venta de unidades productivas';