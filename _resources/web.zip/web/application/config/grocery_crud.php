<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['grocery_crud_default_language']	         = 'spanish';
$config['grocery_crud_date_format']			         = 'sql-date';
$config['grocery_crud_default_per_page']	         = 25; // ex. 10,25,50,100
$config['grocery_crud_file_upload_allow_file_types'] = 'gif|jpeg|jpg|png|tiff|doc|docx|txt|odt|xls|xlsx|pdf|ppt|pptx|pps|ppsx|mp3|m4a|ogg|wav|mp4|m4v|mov|wmv|flv|avi|mpg|ogv|3gp|3g2';
$config['grocery_crud_file_upload_max_file_size'] 	 = '20MB'; // ex. '10MB', '1067KB', '5000B'
$config['grocery_crud_default_text_editor']          = 'ckeditor'; // ex. 'ckeditor','tinymce' or 'markitup'
$config['grocery_crud_text_editor_type'] 	         = 'minimal';
$config['grocery_crud_character_limiter'] 	         = 30;
$config['grocery_crud_dialog_forms']                 = FALSE;