<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Agente_model extends CI_Model {
	
	public function __construct()
	{
		$this->load->database();
		$this->load->library('encrypt');
		$this->load->library('session');
	}
	
	public function login($data)
	{
		$email    = $data['email'];
		$password = $data['password'];
		
		$this->db->select('agent_id,email,password');
		$this->db->from('agent');
		$this->db->where('email',$email);
		$this->db->where('password',$password);
		$this->db->where('status',1);
		$this->db->limit(1);
		$query=$this->db->get();
		
		if($query->num_rows()==1)
		{
			$row = $query->row();
			$data = array(
					'agent_id'  => $row->agent_id,
					'email'     => $row->email,
					'logged_in' => TRUE
			);
			$this->session->set_userdata($data);
			return TRUE;			
		}
		else
		{
			return FALSE;
		}	
	}	
	
	public function registro($data)
	{
		$this->db->insert('agent',$data);
		$id=$this->db->insert_id();		
		return (isset($id)) ? $id : FALSE;		
	}

	public function registro_unidad($data)
	{
		$this->db->insert('company',$data);
		$id=$this->db->insert_id();
		return (isset($id)) ? $id : FALSE;
	}	
		
	public function unidad_update($company_id,$data)
	{
		$this->db->where('company_id',$company_id);
		$this->db->update('company',$data);
	}
	
	public function unidad_delete($company_id)
	{
		$this->db->where('company_id',$company_id);
		$this->db->delete('company');
	}
		
	public function types()
	{
		$this->db->order_by('type','asc');
		$query=$this->db->get('type');
		return $query->result_array();
	}	

}