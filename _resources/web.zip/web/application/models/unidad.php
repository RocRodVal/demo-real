<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Unidad extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}

	public function get_all_sales()
	{
		$this->db->order_by('sale','asc');
		$query = $this->db->get('sale');
		return $query->result_array();
	}	
	
	public function get_all_sales_eng()
	{
		$this->db->order_by('sale_en','asc');
		$query = $this->db->get('sale');
		return $query->result_array();
	}	

	public function get_all_situations()
	{
		$this->db->order_by('situation','asc');
		$query = $this->db->get('situation');
		return $query->result_array();
	}	

	public function get_all_situations_eng()
	{
		$this->db->order_by('situation_en','asc');
		$query = $this->db->get('situation');
		return $query->result_array();
	}
		
	public function get_all_locations()
	{
		$this->db->order_by('location','asc');
		$query = $this->db->get('location');
		return $query->result_array();
	}	
	
	public function get_all_locations_eng()
	{
		$this->db->order_by('location_en','asc');
		$query = $this->db->get('location');
		return $query->result_array();
	}	
	
	public function get_all_sectors()
	{
		$this->db->order_by('sector','asc');
		$query = $this->db->get('sector');
		return $query->result_array();
	}	

	public function get_all_sectors_eng()
	{
		$this->db->order_by('sector_en','asc');
		$query = $this->db->get('sector');
		return $query->result_array();
	}	
	
	public function get_all_cnaes()
	{
		$this->db->order_by('cnae_cod','asc');
		$query = $this->db->get('cnae');
		return $query->result_array();
	}	
	
	public function get_all_provinces()
	{
		$this->db->order_by('province','asc');
		$query = $this->db->get('province');
		return $query->result_array();
	}

	public function get_all_owners()
	{
		$this->db->order_by('owner','asc');
		$query = $this->db->get('owner');
		return $query->result_array();
	}

	public function get_all_owners_eng()
	{
		$this->db->order_by('owner_en','asc');
		$query = $this->db->get('owner');
		return $query->result_array();
	}	
	
	public function get_all_unions()
	{
		$this->db->order_by('union','asc');
		$query = $this->db->get('union');
		return $query->result_array();
	}	

	public function count_sectors()
	{
		$this->db->from('sector');
		$count = $this->db->count_all_results();
		return $count;
	}	
	
	public function count_units()
	{
		$conditions = array('status' => 1);
	
		$this->db->where($conditions);
		$this->db->from('company');
		$count = $this->db->count_all_results();
		return $count;
	}	

	public function count_units_by_sector($sector_id=FALSE)
	{
		$conditions = array('sector_id'=>$sector_id,'status'=>1);
		$this->db->where($conditions);
		$this->db->from('company');
		$count = $this->db->count_all_results();
		return $count;		
	}	
	
	public function get_sector($sector_id=FALSE)
	{
		$query = $this->db->get_where('sector',array('sector_id'=>$sector_id));
		return $query->row_array();
	}

	public function get_units_by_sector($sector_id=FALSE)
	{
		$conditions = array('company.sector_id'=>$sector_id,'company.status'=>1);
		$this->db->select('company.*,
						   province.province AS province,
						   situation.situation AS situation,
					       sale.sale AS sale,
						   location.location AS location');
		$this->db->from('company');
		$this->db->where($conditions);
		$this->db->join('province','company.province_id=province.province_id');
		$this->db->join('situation','company.situation_id=situation.situation_id');
		$this->db->join('sale','company.sale_id=sale.sale_id');
		$this->db->join('location','company.location_id=location.location_id');
		$this->db->order_by('company_id','desc');
		$query = $this->db->get();
		return $query->result_array();		
	}	

	public function get_units_by_sector_eng($sector_id=FALSE)
	{
		$conditions = array('company.sector_id'=>$sector_id,'company.status'=>1);
		$this->db->select('company.*,
						   province.province AS province,
						   situation.situation_en AS situation,
					       sale.sale_en AS sale,
						   location.location_en AS location');
		$this->db->from('company');
		$this->db->where($conditions);
		$this->db->join('province','company.province_id=province.province_id');
		$this->db->join('situation','company.situation_id=situation.situation_id');
		$this->db->join('sale','company.sale_id=sale.sale_id');
		$this->db->join('location','company.location_id=location.location_id');
		$this->db->order_by('company_id','desc');
		$query = $this->db->get();
		return $query->result_array();
	}
	
	
	public function get_units_by_agent($agent_id=FALSE)
	{
		$conditions = array('company.agent_id'=>$agent_id);
		$this->db->select('company.*,
						   province.province AS province,
						   situation.situation AS situation,
					       sale.sale AS sale,
						   location.location AS location');
		$this->db->from('company');
		$this->db->where($conditions);
		$this->db->join('province','company.province_id=province.province_id');
		$this->db->join('situation','company.situation_id=situation.situation_id');
		$this->db->join('sale','company.sale_id=sale.sale_id');
		$this->db->join('location','company.location_id=location.location_id');
		$this->db->order_by('company_id','desc');
		$query = $this->db->get();
		return $query->result_array();
	}	
	
	
	public function get_unit_agent($company_id=FALSE)
	{
		$conditions = array('company.company_id'=>$company_id);
		$this->db->select('company.*,
						   province.province AS province,
						   situation.situation AS situation,
						   sector.sector AS sector,
						   sale.sale AS sale,
						   location.location AS location,
						   owner.owner AS owner,
						   union.union AS sindicato');
		$this->db->from('company');
		$this->db->where($conditions);
		$this->db->join('province','company.province_id=province.province_id');
		$this->db->join('situation','company.situation_id=situation.situation_id');
		$this->db->join('sector','company.sector_id=sector.sector_id');
		$this->db->join('sale','company.sale_id=sale.sale_id');
		$this->db->join('location','company.location_id=location.location_id');
		$this->db->join('owner','company.owner_id=owner.owner_id');
		$this->db->join('union','company.union_id=union.union_id');
		$this->db->order_by('company_id','desc');
		$query = $this->db->get();
		return $query->row_array();
	}	
	
	public function get_unit($company_id=FALSE)
	{
		$conditions = array('company.company_id'=>$company_id,'company.status'=>1);
		$this->db->select('company.*,
						   province.province AS province,
						   situation.situation AS situation,
						   sector.sector AS sector,
						   sale.sale AS sale,
						   location.location AS location,
						   owner.owner AS owner,
						   union.union AS sindicato');
		$this->db->from('company');
		$this->db->where($conditions);
		$this->db->join('province','company.province_id=province.province_id');
		$this->db->join('situation','company.situation_id=situation.situation_id');
		$this->db->join('sector','company.sector_id=sector.sector_id');
		$this->db->join('sale','company.sale_id=sale.sale_id');
		$this->db->join('location','company.location_id=location.location_id');
		$this->db->join('owner','company.owner_id=owner.owner_id');
		$this->db->join('union','company.union_id=union.union_id');								
		$this->db->order_by('company_id','desc');
		$query = $this->db->get();		
		return $query->row_array();
	}	

	
	public function get_unit_eng($company_id=FALSE)
	{
		$conditions = array('company.company_id'=>$company_id,'company.status'=>1);
		$this->db->select('company.*,
						   province.province AS province,
						   situation.situation_en AS situation,
						   sector.sector_en AS sector,
						   sale.sale_en AS sale,
						   location.location_en AS location,
						   owner.owner_en AS owner,
						   union.union AS sindicato');
		$this->db->from('company');
		$this->db->where($conditions);
		$this->db->join('province','company.province_id=province.province_id');
		$this->db->join('situation','company.situation_id=situation.situation_id');
		$this->db->join('sector','company.sector_id=sector.sector_id');
		$this->db->join('sale','company.sale_id=sale.sale_id');
		$this->db->join('location','company.location_id=location.location_id');
		$this->db->join('owner','company.owner_id=owner.owner_id');
		$this->db->join('union','company.union_id=union.union_id');
		$this->db->order_by('company_id','desc');
		$query = $this->db->get();
		return $query->row_array();
	}	
	
	public function get_cnae($cnae_id=FALSE)
	{
		$query = $this->db->get_where('cnae',array('cnae_id'=>$cnae_id));
		return $query->row_array();
	}	
	
	public function buscar($sale_id=FALSE,$situation_id=FALSE,$location_id=FALSE,$volumen=FALSE,$sector_id=FALSE,$cnae_id=FALSE)
	{		
		$this->db->select('company.*,
						   province.province AS province,
						   situation.situation AS situation,
					       sale.sale AS sale,
						   location.location AS location');		
		$this->db->from('company');
		if ($sale_id!=FALSE){$this->db->having('sale_id',$sale_id);}
		if ($situation_id!=FALSE){$this->db->having('situation_id',$situation_id);}
		if ($location_id!=FALSE){$this->db->having('location_id',$location_id);}
		if ($volumen!=FALSE){$this->db->having('volumen',$volumen);}	
		if ($sector_id!=FALSE){$this->db->having('sector_id',$sector_id);}
		if ($cnae_id!=FALSE){$this->db->having('cnae_id',$cnae_id);}		
		$this->db->having('status',1);
		$this->db->join('province','company.province_id=province.province_id');
		$this->db->join('situation','company.situation_id=situation.situation_id');
		$this->db->join('sale','company.sale_id=sale.sale_id');
		$this->db->join('location','company.location_id=location.location_id');		
		$this->db->order_by('company_id','desc');
		$query = $this->db->get();
		return $query->result_array();		
	}	

	public function buscar_eng($sale_id=FALSE,$situation_id=FALSE,$location_id=FALSE,$volumen=FALSE,$sector_id=FALSE,$cnae_id=FALSE)
	{
		$this->db->select('company.*,
						   province.province AS province,
						   situation.situation_en AS situation,
					       sale.sale_en AS sale,
						   location.location_en AS location');
		$this->db->from('company');
		if ($sale_id!=FALSE){$this->db->having('sale_id',$sale_id);}
		if ($situation_id!=FALSE){$this->db->having('situation_id',$situation_id);}
		if ($location_id!=FALSE){$this->db->having('location_id',$location_id);}
		if ($volumen!=FALSE){$this->db->having('volumen',$volumen);}
		if ($sector_id!=FALSE){$this->db->having('sector_id',$sector_id);}
		if ($cnae_id!=FALSE){$this->db->having('cnae_id',$cnae_id);}
		$this->db->having('status',1);
		$this->db->join('province','company.province_id=province.province_id');
		$this->db->join('situation','company.situation_id=situation.situation_id');
		$this->db->join('sale','company.sale_id=sale.sale_id');
		$this->db->join('location','company.location_id=location.location_id');
		$this->db->order_by('company_id','desc');
		$query = $this->db->get();
		return $query->result_array();
	}	
	
}