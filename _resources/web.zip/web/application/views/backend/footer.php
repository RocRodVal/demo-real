
<!-- footer -->
<div class="container-fluid">
	<div class="row-fluid">
		<div class="span1">
		<!-- left sidebar -->
		</div>
		<div class="span7">
			<hr>
			<div class="span7">
				<p class="muted">© 2014 <?=lang('comun.titulo')?></p>
			</div>
		</div>
		<div class="span4">
		<!-- right sidebar -->
		</div>
	</div>
</div>
</body>
</html>