
<!-- content  -->
<div class="container-fluid">
	<div class="row-fluid">
		<div class="span1">
		<!-- left sidebar -->
		</div>
		<div class="span7">
			<?php if (isset($title)): ?>
			<h1><?=$title?></h1>
			<?php else: ?>
			<h1>CMS</h1>
			<?php endif; ?>
			<?=$output?>
		</div>
		<div class="span4">
		<!-- right sidebar -->
		</div>
	</div>
</div>