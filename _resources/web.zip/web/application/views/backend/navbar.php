
<!-- navbar -->
<div class="navbar navbar-inverse navbar-fixed-top">
	<div class="navbar-inner">
		<div class="container-fluid">
			<button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="brand" href="<?=site_url('admin/')?>"><?=lang('navbar.titulo')?></a>
			<div class="nav-collapse collapse">
				<ul class="nav pull-right">
					<li <?=($this->uri->segment(2)==='agent')?'class="active"':''?>><a href="<?=site_url('admin/agent')?>">Agentes</a></li>
					<li <?=($this->uri->segment(2)==='company')?'class="active"':''?>><a href="<?=site_url('admin/company')?>">Unidades productivas</a></li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Herramientas <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li class="nav-header">Agentes</li>
							<li <?=($this->uri->segment(2)==='type')?'class="active"':''?>><a href="<?=site_url('admin/type')?>">Tipo</a></li>
							<li class="divider"></li>
							<li class="nav-header">Unidades</li>
							<li <?=($this->uri->segment(2)==='location')?'class="active"':''?>><a href="<?=site_url('admin/location')?>">Ámbito de negocio</a></li>
							<li <?=($this->uri->segment(2)==='owner')?'class="active"':''?>><a href="<?=site_url('admin/owner')?>">Instalaciones</a></li>
							<li <?=($this->uri->segment(2)==='sector')?'class="active"':''?>><a href="<?=site_url('admin/sector')?>">Sector de actividad</a></li>
							<li <?=($this->uri->segment(2)==='union')?'class="active"':''?>><a href="<?=site_url('admin/union')?>">Sindicato</a></li>
							<li <?=($this->uri->segment(2)==='situation')?'class="active"':''?>><a href="<?=site_url('admin/situation')?>">Situación</a></li>
							<li <?=($this->uri->segment(2)==='sale')?'class="active"':''?>><a href="<?=site_url('admin/sale')?>">Tipo de venta</a></li>							
						</ul>
					</li>
					<li class="dropdown"><a href="<?=site_url('auth/logout')?>"> <i class="icon-off icon-white"></i> Logout </a></li>	
					<!--//<li class="dropdown"><a href="<?=site_url('auth/logout')?>"> <i class="icon-off icon-white"></i> Logout </a></li>//-->			
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div>
</div>