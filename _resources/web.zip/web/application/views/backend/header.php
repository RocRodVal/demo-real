<!DOCTYPE html>
<html lang="es">
<head>
	<title><?=lang('comun.titulo')?> &gt; <?php if (isset($title)): ?><?=$title?><?php else: ?>CMS<?php endif; ?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<!-- styles -->
	<link type="text/css" rel="stylesheet" href="<?=site_url('assets/grocery_crud/themes/twitter-bootstrap/css/style.css')?>" />
	<link type="text/css" rel="stylesheet" href="<?=site_url('assets/grocery_crud/themes/twitter-bootstrap/css/jquery-ui/flick/jquery-ui-1.9.2.custom.css')?>" />
   	<?php
	foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?=$file?>" />
	<?php endforeach; ?>
	<style type="text/css">
	body {
		padding-top: 60px;
		padding-bottom: 40px;
		font-family: Arial;
   		font-size: 14px;		
	}
	a {
   		color: blue;
   		text-decoration: none;
   		font-size: 14px;
	}
	a:hover {
   		text-decoration: underline;
	}	
	</style>
	
	<!-- js -->
    <script src="<?=site_url('assets/grocery_crud/js/jquery-1.9.1.min.js')?>"></script>	
	<?php foreach($js_files as $file): ?>
	<script src="<?=$file?>"></script>
	<?php endforeach; ?>  
    <script src="<?=site_url('assets/grocery_crud/themes/twitter-bootstrap/js/libs/bootstrap/bootstrap-dropdown.js')?>"></script> 	
	
	<!-- favicons -->
	<link rel="shortcut icon" href="<?=site_url('favicon.ico')?>">  
</head>

<body>