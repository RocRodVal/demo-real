<!-- Body -->
<h3><?=$name?></h3>
<ul>
<?php foreach ($unit as $unit_item): ?>
<li>
<a href="<?=site_url('home/unidad_eng')?>/<?=$unit_item['company_id']?>"><strong>+info</strong></a> Registration Code #<?=$unit_item['company_id']?>,
<?=$unit_item['sale']?>, in <?=$unit_item['situation']?>, <?=$unit_item['location']?>, turnover <?=$unit_item['volumen']?>
</li>
<?php endforeach ?>    
</ul>

