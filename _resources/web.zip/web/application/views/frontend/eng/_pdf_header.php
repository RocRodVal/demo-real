<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?=lang('comun.titulo')?> &gt; <?=$title?></title>
	<link rel="stylesheet" href="<?=site_url('assets/css/styles.css')?>" />
</head>

<body>
<h1><a href="<?=site_url('/')?>" title="<?=lang('comun.titulo')?> &gt; Inicio"><img src="<?=site_url('assets/img/logo_arex.jpg')?>" alt="Aragón Exterior" /></a></h1>
<h2><strong>Production Unit</strong><br /> Sale Portal</h2>
