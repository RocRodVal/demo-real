<!-- Body -->
<h3><?=$name?></h3>
<p>
<strong>Incorporation year:</strong> <?=$year?><br />
<strong>Town and Province:</strong> <?=$city?>, <?=$province_id?><br />
<strong>Insolvency:</strong> <?=$situation_id?><br />
<strong>Affiliated companies in the same industry:</strong> <?=$same_sector?><br />
<strong>Affiliated companies in other sectors:</strong> <?=$other_sector?><br />
<strong>Possibility of not improving:</strong> <?=$mejora?>
</p>
<p><strong>Description:</strong></p>
<p><?=$description_en?></p>
<p>
<strong>Sector of activity:</strong> <?=$sector_id?><br />
<strong>CNAE Code:</strong> <?=$cnae_id?><br />
<strong>On sale:</strong> <?=$sale_id?><br />
<strong>Scope of business:</strong> <?=$location_id?>
</p>
<p><strong>Products/main services:</strong></p>
<p><?=$products_en?></p>
<p>
<strong>Facilities:</strong> <?=$owner_id?><br />
<strong>M2 industrial area:</strong> <?=$superficie?><br />
<strong>Representative of the Works Council Union:</strong> <?=$union_id?><br />
<strong>Turnover:</strong> <?=$volumen?><br />
<strong>2012 (in Euros):</strong> <?=$volumen_12?><br />
<strong>2013 (in Euros):</strong> <?=$volumen_13?><br />
<strong>2014 (in Euros):</strong> <?=$volumen_14?><br />
<strong>Total number of workers:</strong> <?=$trabajadores?><br />
<strong>Direct jobs (annual average):</strong> <?=$puestos_directos?><br />
<strong>Indirect jobs (annual average):</strong> <?=$puestos_indirectos?><br />
<strong>Assets volume:</strong> <?=$volumen_activo?><br />
<strong>Liabilities volumen:</strong> <?=$volumen_pasivo?>
</p>
<p><strong>Quality certifications, patents and approvals:</strong></p>
<p><?=$certs_en?></p>
<p><strong>Other data of interest:</strong></p>
<p><?=$more_info_en?></p>
