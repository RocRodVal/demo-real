   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>			
					<p>For further information about the production units that appear on the website, please contact  <strong>Aragón Exterior</strong>:</p>
                    <ul>
	                    <li>Mail: <a href="mailto:invest@aragonexterior.es">invest@aragonexterior.es</a></li>
						<li>Tel: <a href="tel:+34976221571">+34 976 221 571</a></li>
					</ul>	
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/eng/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-eng.png')?>" alt="Contact us" width="189" /></a></p>
                </div>
            </div>
        </div>
