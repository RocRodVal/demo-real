   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
					<p><strong>1. Legal Information</strong></p>
					<p>Aragon Exterior SAU is a public enterprise attached to the Regional Ministry of Economy, Treasury and Employment of the Government of Aragon, with registered offices in C/Alfonso I no. 17, 5pta, Zaragoza and with postcode 50.003. Aragon Exterior SAU is registered in the Trade Registry of Zaragoza, Volume 1054 of the Company Book, Sheet 58, page 2095, registration one, dated 5/6/1991 and with Tax no. A 50467877.</p>
					<p><strong>2. Conditions for access and use of the portal</strong></p>
					<p>Users may access the website of Aragon Exterior without restriction and free of charge.  Users may have to register to access some sections.  Aragon Exterior will provide a password and user name for these sections.  Aragon Exterior may unilaterally modify the configuration and content of the web page without any prior notice.  Users may not use data on the website to make advertising or commercial electronic communications that have not been previously approved.  In addition, users undertake to respect the industrial and intellectual property rights of Aragon Exterior.</p>
					<p><strong>3. Disclaimer</strong></p>
					<p>The portal places some technical devices at users’ disposal in order to access third-party websites.  Aragon Exterior will not assume any responsibility for these sites.  Aragon Exterior will not be responsible for any faults in communication, deadlines or versions produced by telecommunication services or by any other technical services provided by third parties or from external servers.  Aragon Exterior does not guarantee that the website or server are free from viruses and declines any responsibility for damage caused by accessing the website or for not being able to access it.</p>
					<p><strong>4. Intellectual and Industrial Property</strong></p>
					<p>The Intellectual Property Rights of this website belong to Aragon Exterior.  Aragon Exterior may modify its contents and design at any time and without prior notice.  The presentation of the website within another portal's framing is not authorised.</p>
					<p><strong>5. Applicable Law and Jurisdiction</strong></p>
					<p>These general conditions are governed by Spanish law.  For any controversy that may be derived from the application of the services, or interpretation or application of the general conditions, Aragon Exterior and the user will expressly relinquish their own jurisdiction, submitting themselves to the Courts and Tribunals of Zaragoza.</p>
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/eng/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-eng.png')?>" alt="Contact us" width="189" /></a></p>
                </div>
            </div>
        </div>
