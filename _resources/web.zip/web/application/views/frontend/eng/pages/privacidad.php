   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
					<p>Pursuant to Spanish Organic Law 15/1999, of 13 December, on Data Protection (LOPD); amended by Law 62/2003, of 30 December, on tax, administrative and social type measures, and in ruling 292/2000, of 30 November, passed in constitutional challenge 1463/2000 (Official State Journal no. 4, of 4 January 2001), the data supplied by users will be incorporated into an computer file and will be collected through the relative mechanisms, which will only contain the necessary fields to be able to provide the service required by the users.</p>
					<p>Personal data will be adequately treated pursuant to Royal Decree 994/1999, of 11 June, approving the regulation on security measures of computer files that contain personal data.  The necessary security measures are also taken to avoid their alteration, loss, or unauthorised processing or access by third parties. Personal data may only be transferred, according to that stipulated in article 11 of Organic Law 15/1999, of 13 December, in order to fulfil the objectives directly related to the legitimate functions of the assigner and assignee, with prior consent from the affected party.</p>                    
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/eng/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-eng.png')?>" alt="Contact us" width="189" /></a></p>
                </div>
            </div>
        </div>
