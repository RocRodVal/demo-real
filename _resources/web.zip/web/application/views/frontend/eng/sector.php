   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
					<p>For further information about the production units that appear on the website, please contact  <strong>Aragón Exterior</strong>:</p>
                    <ul>
	                    <li>Mail: <a href="mailto:invest@aragonexterior.es">invest@aragonexterior.es</a></li>
						<li>Tel: <a href="tel:+34976221571">+34 976 221 571</a></li>
					</ul>	                   
		            <p><a href="javascript:history.back()"><strong>&lt;&lt; Back</strong></a> | <a href="<?=site_url('home/sector_eng/'.$this->uri->segment(3).'/pdf')?>" target="_blank"><strong>Export as PDF</strong></a></p>
                    <ul class="listado">
		         	<?php foreach ($unit as $unit_item): ?>
		         	<li>
		            	<a href="<?=site_url('home/unidad_eng')?>/<?=$unit_item['company_id']?>"><strong>+info</strong></a> Registration Code #<?=$unit_item['company_id']?>,
		            	<?=$unit_item['sale']?>, in <?=$unit_item['situation']?>, <?=$unit_item['location']?>, turnover <?=$unit_item['volumen']?>
		            </li>
		            <?php endforeach ?>    
		            </ul>     	
		            <p><a href="javascript:history.back()"><strong>&lt;&lt; Back</strong></a> | <a href="<?=site_url('home/sector_eng/'.$this->uri->segment(3).'/pdf')?>" target="_blank"><strong>Export as PDF</strong></a></p>
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<form action="<?=site_url('home/buscar_eng');?>" method="post" class="container_100">
                    <h2>Advanced Search</h2>
                    	<ul class="block">
                            <li>
								<a href="#" class="tooltip" >
								    <img src="<?=site_url('assets/img/info.png')?>" width="20" />
								    <span>
								        <img class="callout" src="<?=site_url('assets/img/tooltip.gif')?>" />
								        <strong>Type of sale</strong><br />
								        <em>Complete production unit:</em> sale of the whole company<br />
										<em>Sale of production unit:</em> part of the company that can be considered as an independent business<br />
								        <strong>Insolvency</strong><br />
								        <em>Pre-tender:</em> situation prior to bankruptcy, which allows negotiations with creditors before trial<br />
										<em>Tender:</em> trial process										
								    </span>
								</a>                      
					            <select class="form-control" id="sale_id" name="sale_id">
					            <option value="">-- Type of sale --</option>
					            <?php foreach ($sale as $sale_item): ?>
					            <option value="<?=$sale_item['sale_id']?>"><?=$sale_item['sale_en']?></option>
					            <?php endforeach ?>
					            </select>   
                            </li>
                            <li>
					            <select class="form-control" id="situation_id" name="situation_id">
					            <option value="">-- Insolvency --</option>
					            <?php foreach ($situation as $situation_item): ?>
					            <option value="<?=$situation_item['situation_id']?>"><?=$situation_item['situation_en']?></option>
					            <?php endforeach ?>  
					            </select>
                            </li>
                            <li>
					            <select class="form-control" id="location_id" name="location_id">
					            <option value="">-- Scope of business --</option>
					            <?php foreach ($location as $location_item): ?>
					            <option value="<?=$location_item['location_id']?>"><?=$location_item['location_en']?></option>
					            <?php endforeach ?>  
				            	</select>
                            </li>
                            <li>
					            <select class="form-control" id="volumen" name="volumen">
					            <option value="">-- Turnover --</option>
					            <option value="Inferior a 1.000.000 €">Below 1.000.000 €</option>
					            <option value="Superior a 1.000.000 €">Above 1.000.000 €</option>
					            </select>                            
                            </li>
                            <li>
					            <select class="form-control" id="sector_id" name="sector_id">
					            <option value="">-- Sector of activity --</option>
					            <?php foreach ($sector as $sector_item): ?>
					            <option value="<?=$sector_item['sector_id']?>"><?=$sector_item['sector_en']?></option>
					            <?php endforeach ?>
					            </select>                            
                            </li>
                            <li>
					            <select class="form-control" id="cnae_id" name="cnae_id">
					            <option value="">-- CNAE Code --</option>
					            <?php foreach ($cnae as $cnae_item): ?>
					            <option value="<?=$cnae_item['cnae_id']?>"><?=$cnae_item['cnae_cod']?> <?=$cnae_item['name']?></option>
					            <?php endforeach ?>
					            </select>                            
                            </li>                            
                        </ul> 
                        <p class="botonera"><input type="submit" class="submit" value="search" /></p>                 
                    </form>
                </div>                      
            </div>
        </div>
