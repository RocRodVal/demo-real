   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
					<p>For further information about the production units that appear on the website, please contact  <strong>Aragón Exterior</strong>:</p>
                    <ul>
	                    <li>Mail: <a href="mailto:invest@aragonexterior.es">invest@aragonexterior.es</a></li>
						<li>Tel: <a href="tel:+34976221571">+34 976 221 571</a></li>
					</ul>	                    
		          	<p><a href="javascript:history.back()"><strong>&lt;&lt; Back</strong></a> | <a href="<?=site_url('home/unidad_eng/'.$this->uri->segment(3).'/pdf')?>" target="_blank"><strong>Export as PDF</strong></a></p> 
					
					<div class="container_100">
                   		<h2>Activity</h2>
                    	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Sector of activity:</td>
                                <td><?=$sector_id?></td>
                            </tr>
                            <tr> 
                            	<td class="tit">CNAE Code:</td>
                                <td><?=$cnae_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Quality certifications, patents and approvals:</td>
                                <td><?=$certs_en?></td>
                            </tr>
                        </table>
                        <h3>Products/main services</h3>
                        <div class="cuadro">
                        	<p><?=$products_en?></p>
                        </div>
                        
                        <h3>Description</h3>
                        <div class="cuadro">
                        	<p><?=$description_en?></p>
                        </div>                                            
                    </div>

                    
                    <div class="container_100">
                    	<div class="columna">
                        <h3>Economic Reports</h3>
                       	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Turnover:</td>
                                <td class="num"><?=$volumen?></td>
                            </tr>
                            <tr>
                            	<td class="tit centered">2012 (in Euros):</td>
                                <td class="num"><?=$volumen_12?> &euro;</td>
                            </tr>
                            <tr>
                            	<td class="tit centered">2013 (in Euros):</td>
                                <td class="num"><?=$volumen_13?> &euro;</td>
                            </tr>
                            <tr>
                            	<td class="tit centered">2014 (in Euros):</td>
                                <td class="num"><?=$volumen_14?> &euro;</td>
                            </tr>
                        	<tr>
                            	<td class="tit">Scope of business:</td>
                                <td class="num"><?=$location_id?></td>
                            </tr>
                        	<tr>
                            	<td class="tit">Affiliated companies in the same industry:</td>
                                <td class="num"><?=$same_sector?></td>
                            </tr>
                         	<tr>
                            	<td class="tit">Affiliated companies in other sectors:</td>
                                <td class="num"><?=$other_sector?></td>
                            </tr>                                                                                   
                        </table>
                        </div>
                        
                        <div class="columna">
                        <h3>Bankruptcy information</h3>
                       	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Insolvency:</td>
                                <td><?=$situation_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">On sale:</td>
                                <td><?=$sale_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Representative of the Works Council Union:</td>
                                <td><?=$union_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Possibility of not improving:</td>
                                <td><?=$mejora?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Assets volume:</td>
                                <td class="num"><?=$volumen_activo?> &euro;</td>
                            </tr>
                            <tr>
                            	<td class="tit">Liabilities volumen:</td>
                                <td class="num"><?=$volumen_pasivo?> &euro;</td>
                            </tr>
                        </table>
                        </div>                    
                    </div>
                    
                    <div class="container_100">
                    	<div class="columna">
                        <h3>Employment</h3>
                       	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Total number of workers:</td>
                                <td><?=$trabajadores?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Direct jobs (annual average):</td>
                                <td><?=$puestos_directos?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Indirect jobs (annual average):</td>
                                <td><?=$puestos_indirectos?></td>
                            </tr>                           
                        </table>
                        </div>
                        
                        <div class="columna">
                        <h3>Location and facilities</h3>
                       	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Town and Province:</td>
                                <td><?=$city?>, <?=$province_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Facilities:</td>
                                <td><?=$owner_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">M<sup>2</sup> industrial area:</td>
                                <td class="num"><?=$superficie?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Incorporation year:</td>
                                <td class="num"><?=$year?></td>
                            </tr>
                        </table>
                        </div>                    
                    </div>
                    
                    <div class="container_100">
                    	<h3>Other data of interest:</h3>
                    	<div class="cuadro">
                        	<p><?=$more_info_en?></p>
                        </div>
                    </div>		         	

                    <p><a href="javascript:history.back()"><strong>&lt;&lt; Back</strong></a> | <a href="<?=site_url('home/unidad_eng/'.$this->uri->segment(3).'/pdf')?>" target="_blank"><strong>Export as PDF</strong></a></p>
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<form action="<?=site_url('home/buscar_eng');?>" method="post" class="container_100">
                    <h2>Advanced Search</h2>
                    	<ul class="block">
                            <li>
								<a href="#" class="tooltip" >
								    <img src="<?=site_url('assets/img/info.png')?>" width="20" />
								    <span>
								        <img class="callout" src="<?=site_url('assets/img/tooltip.gif')?>" />
								        <strong>Type of sale</strong><br />
								        <em>Complete production unit:</em> sale of the whole company<br />
										<em>Sale of production unit:</em> part of the company that can be considered as an independent business<br />
								        <strong>Insolvency</strong><br />
								        <em>Pre-tender:</em> situation prior to bankruptcy, which allows negotiations with creditors before trial<br />
										<em>Tender:</em> trial process										
								    </span>
								</a>                      
					            <select class="form-control" id="sale_id" name="sale_id">
					            <option value="">-- Type of sale --</option>
					            <?php foreach ($sale as $sale_item): ?>
					            <option value="<?=$sale_item['sale_id']?>"><?=$sale_item['sale_en']?></option>
					            <?php endforeach ?>
					            </select>   
                            </li>
                            <li>
					            <select class="form-control" id="situation_id" name="situation_id">
					            <option value="">-- Insolvency --</option>
					            <?php foreach ($situation as $situation_item): ?>
					            <option value="<?=$situation_item['situation_id']?>"><?=$situation_item['situation_en']?></option>
					            <?php endforeach ?>  
					            </select>
                            </li>
                            <li>
					            <select class="form-control" id="location_id" name="location_id">
					            <option value="">-- Scope of business --</option>
					            <?php foreach ($location as $location_item): ?>
					            <option value="<?=$location_item['location_id']?>"><?=$location_item['location_en']?></option>
					            <?php endforeach ?>  
				            	</select>
                            </li>
                            <li>
					            <select class="form-control" id="volumen" name="volumen">
					            <option value="">-- Turnover --</option>
					            <option value="Inferior a 1.000.000 €">Below 1.000.000 €</option>
					            <option value="Superior a 1.000.000 €">Above 1.000.000 €</option>
					            </select>                            
                            </li>
                            <li>
					            <select class="form-control" id="sector_id" name="sector_id">
					            <option value="">-- Sector of activity --</option>
					            <?php foreach ($sector as $sector_item): ?>
					            <option value="<?=$sector_item['sector_id']?>"><?=$sector_item['sector_en']?></option>
					            <?php endforeach ?>
					            </select>                            
                            </li>
                            <li>
					            <select class="form-control" id="cnae_id" name="cnae_id">
					            <option value="">-- CNAE Code --</option>
					            <?php foreach ($cnae as $cnae_item): ?>
					            <option value="<?=$cnae_item['cnae_id']?>"><?=$cnae_item['cnae_cod']?> <?=$cnae_item['name']?></option>
					            <?php endforeach ?>
					            </select>                            
                            </li>                            
                        </ul> 
                        <p class="botonera"><input type="submit" class="submit" value="search" /></p>                 
                    </form>
                </div>                      
            </div>
        </div>
