<!-- Footer -->
<!--
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>
<a href="http://www.reicaz.org.es" target="_blank" title="Ir al sitio web del Real e Ilustre Colegio de Abogados de Zaragoza (ventana nueva)"><img src="<?=site_url('assets/img/logo_abogados.jpg')?>" alt="Real e Ilustre Colegio de Abogados de Zaragoza" /></a>
<a href="http://www.ecoara.org" target="_blank" title="Ir al sitio web del Colegio Oficial de Economistas de Aragón (ventana nueva)"><img src="<?=site_url('assets/img/logo_economistas.jpg')?>" alt="Colegio Oficial de Economistas de Aragón" /></a>
<a href="http://www.cotme.com" target="_blank" title="Ir al sitio web del Ilustre Colegio Oficial de Titulados Mercantiles y Empresariales de Aragón (ventana nueva)"><img src="<?=site_url('assets/img/logo_cotme.jpg')?>" alt="Ilustre Colegio Oficial de Titulados Mercantiles y Empresariales de Aragón" /></a>
<a href="http://www.censores.com" target="_blank" title="Ir al sitio web del Instituto de Censores Jurados de Cuentas. Agrupación Territorial 8º Aragón (ventana nueva)"><img src="<?=site_url('assets/img/logo_auditores.jpg')?>" alt="Instituto de Censores Jurados de Cuentas. Agrupación Territorial 8º Aragón" /></a>
<a href="http://www.aragon.es" target="_blank" title="Ir al sitio web del Gobierno de Aragón (ventana nueva)"><img src="<?=site_url('assets/img/logo_gobierno_aragon.jpg')?>" alt="Gobierno de Aragón" /></a>
</p>
-->
</body>
</html>