<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="<?=site_url('favicon.ico')?>">
	<title><?=lang('comun.titulo')?> &gt; <?=$title?></title>
	<link rel="stylesheet" href="<?=site_url('assets/css/layout.css')?>" />
	<link rel="stylesheet" href="<?=site_url('assets/css/styles.css')?>" />
	<link rel="stylesheet" href="<?=site_url('assets/css/animate.min.css')?>" />
	<link rel="stylesheet" href="<?=site_url('assets/css/slider.css')?>" />
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="<?=site_url('assets/js/main.js')?>"></script>
	<script src="<?=site_url('assets/js/jquery.sudoSlider.min.js')?>"></script>
    <script type="text/javascript" >
	$(document).ready(function(){
		var sudoSlider = $("#slider").sudoSlider({
			numeric: true,
			continuous:true
		});
	});
	</script>	
</head>

<body>
<!--[if lt IE 7]>
	<p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
<![endif]-->
  
<div id="container" class="container_100">

	<div id="header" class="container_100">
    	<div class="container_auto">
    	  	<h1><a href="<?=site_url('/')?>" title="<?=lang('comun.titulo')?> &gt; Inicio"><img src="<?=site_url('assets/img/head_buscador.png')?>" alt="<?=lang('comun.titulo')?> &gt; Inicio" /></a></h1>
            <div id="intro" class="content_auto">
            	<h2>Portal de venta<br />de <strong>Unidades Productivas</strong></h2>
            </div>
            <p class="lang"><a href="<?=site_url('/')?>" title="<?=lang('comun.titulo')?>" class="selected">es</a> | <a href="<?=site_url('/home/eng')?>" title="Production Unit Sale Portal">en</a></p>
            <span><a href="http://www.aragonexterior.es/" title="Aragón Exterior" target="_blank"><img src="<?=site_url('assets/img/logo_arex.jpg')?>" alt="Aragón Exterior" /></a></span>
        </div>
    </div>
        
    <div id="introduccion" class="container_100">
    	<div class="container_auto">
		<div class="texto content_auto">
        	<p>El <strong>Gobierno de Aragón</strong> junto con los <strong>Colegios Profesionales de Abogados de Zaragoza</strong>, <strong>Economistas</strong>, <strong>Titulados Mercantiles</strong> y <strong>Censores Jurados de Cuentas de Aragón</strong>, difunde las unidades productivas y activos en situación de preconcurso o concurso de acreedores en Aragón.</p>
            <p>En esta página, los interesados podrán acceder a información completa sobre estos activos en venta y solicitar información ampliada.</p>
        </div>
                
        <div class="imagenes content_auto">
        	<img src="<?=site_url('assets/img/head_fabrica.jpg')?>" alt="Fábrica" />
            <img src="<?=site_url('assets/img/head_engranaje.jpg')?>" alt="Engranaje" />
            <img src="<?=site_url('assets/img/head_bodega.jpg')?>" alt="Bodega" />
        </div>
            </div>
        </div>
