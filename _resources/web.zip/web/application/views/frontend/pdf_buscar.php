<!-- Body -->
<h3><?=$name?></h3>
<?php
if(empty($unit))
{
?>
<p><strong>No hay resultados para los criterios de búsqueda.</strong></p>
<?php
} 
else 
{	        	 
?>
<ul>
<?php foreach ($unit as $unit_item): ?>
<li>
<a href="<?=site_url('home/unidad')?>/<?=$unit_item['company_id']?>"><strong>+info</strong></a> Código registro #<?=$unit_item['company_id']?>,
fundada en <?=$unit_item['year']?>, en <?=$unit_item['situation']?>, de <?=$unit_item['province']?>, negocio <?=$unit_item['volumen']?>
</li>
<?php endforeach ?>   
</ul>
<?php 
}
?>
