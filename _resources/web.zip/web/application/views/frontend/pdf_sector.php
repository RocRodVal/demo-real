<!-- Body -->
<h3><?=$name?></h3>
<ul>
<?php foreach ($unit as $unit_item): ?>
<li>
<a href="<?=site_url('home/unidad')?>/<?=$unit_item['company_id']?>"><strong>+info</strong></a> Código registro #<?=$unit_item['company_id']?>,
<?=$unit_item['sale']?>, en <?=$unit_item['situation']?>, <?=$unit_item['location']?>, negocio <?=$unit_item['volumen']?>
</li>
<?php endforeach ?>    
</ul>

