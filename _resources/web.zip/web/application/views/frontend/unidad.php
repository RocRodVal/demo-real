   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
					<p>Para más información sobre las unidades productivas que aparecen en la web contacte con <strong>Aragón Exterior</strong>:</p>
                    <ul>
	                    <li>Mail: <a href="mailto:invest@aragonexterior.es">invest@aragonexterior.es</a></li>
						<li>Tel: <a href="tel:976221571">976 221 571</a></li>
					</ul>	                    
		          	<p><a href="javascript:history.back()"><strong>&lt;&lt; Volver</strong></a> | <a href="<?=site_url('home/unidad/'.$this->uri->segment(3).'/pdf')?>" target="_blank"><strong>Exportar en PDF</strong></a></p> 
					
					<div class="container_100">
                   		<h2>Actividad</h2>
                    	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Sector de actividad:</td>
                                <td><?=$sector_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Código CNAE:</td>
                                <td><?=$cnae_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Certificaciones de calidad, patentes y homologaciones:</td>
                                <td><?=$certs?></td>
                            </tr>
                        </table>
                        <h3>Productos/servicios principales</h3>
                        <div class="cuadro">
                        	<p><?=$products?></p>
                        </div>
                        
                        <h3>Descripción</h3>
                        <div class="cuadro">
                        	<p><?=$description?></p>
                        </div>                                            
                    </div>

                    
                    <div class="container_100">
                    	<div class="columna">
                        <h3>Información económica</h3>
                       	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Volumen de negocio:</td>
                                <td class="num"><?=$volumen?></td>
                            </tr>
                            <tr>
                            	<td class="tit centered">2012 (en euros):</td>
                                <td class="num"><?=$volumen_12?> &euro;</td>
                            </tr>
                            <tr>
                            	<td class="tit centered">2013 (en euros):</td>
                                <td class="num"><?=$volumen_13?> &euro;</td>
                            </tr>
                            <tr>
                            	<td class="tit centered">2014 (en euros):</td>
                                <td class="num"><?=$volumen_14?> &euro;</td>
                            </tr>
                        	<tr>
                            	<td class="tit">Zona de actuación:</td>
                                <td class="num"><?=$location_id?></td>
                            </tr>
                        	<tr>
                            	<td class="tit">Empresas participadas en el mismo sector:</td>
                                <td class="num"><?=$same_sector?></td>
                            </tr>
                         	<tr>
                            	<td class="tit">Empresas participadas en otros sectores:</td>
                                <td class="num"><?=$other_sector?></td>
                            </tr>                                                                                   
                        </table>
                        </div>
                        
                        <div class="columna">
                        <h3>Información concursal</h3>
                       	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Situación concursal:</td>
                                <td><?=$situation_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">En venta:</td>
                                <td><?=$sale_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Sindicato representativo del Comité de Empresa:</td>
                                <td><?=$union_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Posibilidad de renunciar a la mejora:</td>
                                <td><?=$mejora?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Volumen activo:</td>
                                <td class="num"><?=$volumen_activo?> &euro;</td>
                            </tr>
                            <tr>
                            	<td class="tit">Volumen pasivo:</td>
                                <td class="num"><?=$volumen_pasivo?> &euro;</td>
                            </tr>
                        </table>
                        </div>                    
                    </div>
                    
                    <div class="container_100">
                    	<div class="columna">
                        <h3>Empleo</h3>
                       	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Número total de trabajadores:</td>
                                <td><?=$trabajadores?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Puestos de trabajo directos (media anual):</td>
                                <td><?=$puestos_directos?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Puestos de trabajo indirectos (media anual):</td>
                                <td><?=$puestos_indirectos?></td>
                            </tr>                           
                        </table>
                        </div>
                        
                        <div class="columna">
                        <h3>Localización e instalaciones</h3>
                       	<table cellpadding="0" cellspacing="0" width="100%" class="datos">
                        	<tr>
                            	<td class="tit">Población y provincia:</td>
                                <td><?=$city?>, <?=$province_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Instalaciones:</td>
                                <td><?=$owner_id?></td>
                            </tr>
                            <tr>
                            	<td class="tit">M<sup>2</sup> de superficie industrial:</td>
                                <td class="num"><?=$superficie?></td>
                            </tr>
                            <tr>
                            	<td class="tit">Año de fundación:</td>
                                <td class="num"><?=$year?></td>
                            </tr>
                        </table>
                        </div>                    
                    </div>
                    
                    <div class="container_100">
                    	<h3>Otros datos de interés:</h3>
                    	<div class="cuadro">
                        	<p><?=$more_info?></p>
                        </div>
                    </div>		         	

                    <p><a href="javascript:history.back()"><strong>&lt;&lt; Volver</strong></a> | <a href="<?=site_url('home/unidad/'.$this->uri->segment(3).'/pdf')?>" target="_blank"><strong>Exportar en PDF</strong></a></p>
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<form action="<?=site_url('home/buscar');?>" method="post" class="container_100">
                    <h2>Búsqueda avanzada</h2>
                    	<ul class="block">
                            <li>
								<a href="#" class="tooltip" >
								    <img src="<?=site_url('assets/img/info.png')?>" width="20" />
								    <span>
								        <img class="callout" src="<?=site_url('assets/img/tooltip.gif')?>" />
								        <strong>Tipo de venta</strong><br />
								        <em>Unidad productiva completa:</em> venta de una empresa en su totalidad<br />
										<em>Venta de unidad productiva:</em> venta de una parte de la empresa que pueda ser desgajada de la misma<br />
								        <strong>Situación concursal</strong><br />
								        <em>Preconcurso:</em> paso previo a la declaración de concurso, que permite negociar con los acreedores antes del proceso judicial<br />
										<em>Concurso:</em> en proceso judicial										
								    </span>
								</a>                            
					            <select class="form-control" id="sale_id" name="sale_id">
					            <option value="">-- Tipo de venta --</option>
					            <?php foreach ($sale as $sale_item): ?>
					            <option value="<?=$sale_item['sale_id']?>"><?=$sale_item['sale']?></option>
					            <?php endforeach ?>
					            </select>   
                            </li>
                            <li>
					            <select class="form-control" id="situation_id" name="situation_id">
					            <option value="">-- Situación concursal --</option>
					            <?php foreach ($situation as $situation_item): ?>
					            <option value="<?=$situation_item['situation_id']?>"><?=$situation_item['situation']?></option>
					            <?php endforeach ?>  
					            </select>
                            </li>
                            <li>
					            <select class="form-control" id="location_id" name="location_id">
					            <option value="">-- Ámbito de negocio --</option>
					            <?php foreach ($location as $location_item): ?>
					            <option value="<?=$location_item['location_id']?>"><?=$location_item['location']?></option>
					            <?php endforeach ?>  
				            	</select>
                            </li>
                            <li>
					            <select class="form-control" id="volumen" name="volumen">
					            <option value="">-- Volumen de negocio --</option>
					            <option value="Inferior a 1.000.000 €">Inferior a 1.000.000 €</option>
					            <option value="Superior a 1.000.000 €">Superior a 1.000.000 €</option>
					            </select>                            
                            </li>
                            <li>
					            <select class="form-control" id="sector_id" name="sector_id">
					            <option value="">-- Sector de actividad --</option>
					            <?php foreach ($sector as $sector_item): ?>
					            <option value="<?=$sector_item['sector_id']?>"><?=$sector_item['sector']?></option>
					            <?php endforeach ?>
					            </select>                            
                            </li>
                            <li>
					            <select class="form-control" id="cnae_id" name="cnae_id">
					            <option value="">-- Código CNAE --</option>
					            <?php foreach ($cnae as $cnae_item): ?>
					            <option value="<?=$cnae_item['cnae_id']?>"><?=$cnae_item['cnae_cod']?> <?=$cnae_item['name']?></option>
					            <?php endforeach ?>
					            </select>                            
                            </li>                            
                        </ul>    
                        <p class="botonera"><input type="submit" class="submit" value="buscar" /></p>                 
                    </form>
                </div>                      
            </div>
        </div>
