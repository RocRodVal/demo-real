   	  <!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                	<div id="slideshow">
                    	<div class="mask">                       	
                        <div id="slider">
                        	<ul class="slides">
		                    	<?php
		                    	$key = 1;
		                    	foreach ($sector as $sector_item):
		                    	if ($key === 1)
		                    	{
		                    	?>
		                    	<li>
		                    	<?php	
		                    	}
		                    	
		                    	if ($key === 6) 
		                    	{
			                    	if (($this->unidad->count_units_by_sector($sector_item['sector_id'])) != 0)
			                    	{
			                    	?>
			                    	<p class="<?php echo ($key + 1) % 2 ? 'slide color-2 last' : 'slide color-1 last'; ?>"><a href="<?=site_url('home/sector')?>/<?=$sector_item['sector_id']?>"><?=$sector_item['sector']?> <span>Unidades: <strong><?=$this->unidad->count_units_by_sector($sector_item['sector_id'])?></strong></span></a></p>
			                    	<?php
			                    	}
			                    	else 
			                    	{
			                    	?>
			                    	<p class="<?php echo ($key + 1) % 2 ? 'slide color-2 last' : 'slide color-1 last'; ?>"><a href="#"><?=$sector_item['sector']?> <span>Unidades: <strong><?=$this->unidad->count_units_by_sector($sector_item['sector_id'])?></strong></span></a></p>
			                    	<?php	
			                    	}		
		                    		$key = 0;
		                    		?>
		                    		</li>
		                    		<?php
		                    	}
		                    	else
		                    	{	
			                    	if (($this->unidad->count_units_by_sector($sector_item['sector_id'])) != 0)
			                    	{
			                    	?>
			                    	<p class="<?php echo ($key + 1) % 2 ? 'slide color-2' : 'slide color-1'; ?>"><a href="<?=site_url('home/sector')?>/<?=$sector_item['sector_id']?>"><?=$sector_item['sector']?> <span>Unidades: <strong><?=$this->unidad->count_units_by_sector($sector_item['sector_id'])?></strong></span></a></p>
			                    	<?php
			                    	}
			                    	else 
			                    	{
			                    	?>
			                    	<p class="<?php echo ($key + 1) % 2 ? 'slide color-2' : 'slide color-1'; ?>"><a href="#"><?=$sector_item['sector']?> <span>Unidades: <strong><?=$this->unidad->count_units_by_sector($sector_item['sector_id'])?></strong></span></a></p>
			                    	<?php	
			                    	}	                    	
		                    	}		
		                        ++$key;
		                        endforeach 
		                        ?>                        	
                             </ul>                             
                        </div>
                        </div>
                    </div>                                 
                </div>
                
                <div id="sidebar" class="content_auto">
                	<!-- agentes -->
                	<a href="<?=site_url('agente')?>" class="boton" title="Acceso de Agentes">Acceso de Agentes</a>             
                	<form action="<?=site_url('home/buscar');?>" method="post" class="container_100">
                    <h2>Búsqueda avanzada</h2>
                    	<ul class="block">
                            <li>
								<a href="#" class="tooltip" >
								    <img src="<?=site_url('assets/img/info.png')?>" width="20" />
								    <span>
								        <img class="callout" src="<?=site_url('assets/img/tooltip.gif')?>" />
								        <strong>Tipo de venta</strong><br />
								        <em>Unidad productiva completa:</em> venta de una empresa en su totalidad<br />
										<em>Venta de unidad productiva:</em> venta de una parte de la empresa que pueda ser desgajada de la misma<br />
								        <strong>Situación concursal</strong><br />
								        <em>Preconcurso:</em> paso previo a la declaración de concurso, que permite negociar con los acreedores antes del proceso judicial<br />
										<em>Concurso:</em> en proceso judicial										
								    </span>
								</a>                    
					            <select class="form-control" id="sale_id" name="sale_id">
					            <option value="">-- Tipo de venta --</option>
					            <?php foreach ($sale as $sale_item): ?>
					            <option value="<?=$sale_item['sale_id']?>"><?=$sale_item['sale']?></option>
					            <?php endforeach ?>
					            </select>					              
                            </li>
                            <li>                           
					            <select class="form-control" id="situation_id" name="situation_id">
					            <option value="">-- Situación concursal --</option>
					            <?php foreach ($situation as $situation_item): ?>
					            <option value="<?=$situation_item['situation_id']?>"><?=$situation_item['situation']?></option>
					            <?php endforeach ?>  
					            </select>						            
                            </li>
                            <li>
					            <select class="form-control" id="location_id" name="location_id">
					            <option value="">-- Ámbito de negocio --</option>
					            <?php foreach ($location as $location_item): ?>
					            <option value="<?=$location_item['location_id']?>"><?=$location_item['location']?></option>
					            <?php endforeach ?>  
				            	</select>
                            </li>
                            <li>
					            <select class="form-control" id="volumen" name="volumen">
					            <option value="">-- Volumen de negocio --</option>
					            <option value="Inferior a 1.000.000 €">Inferior a 1.000.000 €</option>
					            <option value="Superior a 1.000.000 €">Superior a 1.000.000 €</option>
					            </select>                            
                            </li>
                            <li>
					            <select class="form-control" id="sector_id" name="sector_id">
					            <option value="">-- Sector de actividad --</option>
					            <?php foreach ($sector as $sector_item): ?>
					            <option value="<?=$sector_item['sector_id']?>"><?=$sector_item['sector']?></option>
					            <?php endforeach ?>
					            </select>                            
                            </li>
                            <li>
					            <select class="form-control" id="cnae_id" name="cnae_id">
					            <option value="">-- Código CNAE --</option>
					            <?php foreach ($cnae as $cnae_item): ?>
					            <option value="<?=$cnae_item['cnae_id']?>"><?=$cnae_item['cnae_cod']?> <?=$cnae_item['name']?></option>
					            <?php endforeach ?>
					            </select>                            
                            </li>                            
                        </ul> 
                        <p class="botonera"><input type="submit" class="submit" value="buscar" /></p>                 
                    </form>
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>                    
                </div>                      
            </div>
        </div>
