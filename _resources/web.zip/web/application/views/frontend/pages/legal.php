   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
					<p><strong>1. Información legal</strong></p>
					<p>Aragón Exterior SAU es una empresa pública adscrita a la Consejería de Economía, Hacienda y Empleo del Gobierno de Aragón, con domicilio social en la C/Alfonso I nº17, 5pta de Zaragoza y código postal 50.003. Aragón Exterior SAU está inscrito en el Registro Mercantil de Zaragoza, Tomo 1.054 del Libro de Sociedades, Folio 58, hoja 2.095, inscripción primera de fecha 5/6/1991 y con CIF A 50467877.</p>
					<p><strong>2. Condiciones de acceso y utilización del portal</strong></p>
					<p>Los usuarios podrán acceder a la web de Aragón Exterior de forma libre y gratuita. Algunos apartados pueden requerir el registro previo de los usuarios. Aragón Exterior facilitará una contraseña y nombre de usuario para estos apartados. Aragón Exterior podrá modificar de forma unilateral y sin aviso previo la configuración y el contenido de la página web. El usuario no podrá utilizar los datos de la web para realizar comunicaciones electrónicas publicitarias o comerciales, no consentidas previamente. Asimismo se compromete a respetar los derechos de propiedad intelectual e industrial de Aragón Exterior.</p>
					<p><strong>3. Exoneración de responsabilidad</strong></p>
					<p>El portal pone a disposición de los usuarios dispositivos técnicos para acceder a páginas web de terceros. Aragón Exterior no asumirá ninguna responsabilidad sobre dichas páginas. Aragón Exterior no será responsable de los fallos en la comunicación, plazos o versiones producidos por servicios de telecomunicación o por cualesquiera otros servicios técnicos prestados por terceras personas o desde servidores ajenos. Aragón Exterior no garantiza que la web y el servidor estén libres de virus y no se hacen responsables de los daños causados por el acceso a la web o por la imposibilidad de acceder a ésta.</p>
					<p><strong>4. Propiedad Intelectual e Industrial</strong></p>
					<p>Los Derechos de Propiedad intelectual de esta web son titularidad del Aragón Exterior. Aragón Exterior podrá modificar en cualquier momento y sin previo aviso sus contenidos y diseño. No está autorizada la presentación de la web en un marco de otro portal o framing.</p>
					<p><strong>5. Ley Aplicable y Fuero</strong></p>
					<p>Estas Condiciones Generales se rigen por la ley española. Para cualquier controversia que pudiera derivarse de la aplicación de los servicios o interpretación o aplicación de las Condiciones Generales, Aragón Exterior y el usuario, con renuncia expresa a su fuero propio se someten al de los Juzgados y Tribunales de Zaragoza.</p> 
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
