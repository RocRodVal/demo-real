   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
                    <p>Para dudas sobre el funcionamiento de la web, por favor contacte con su colegio:</p>
                    <ul>
	                    <li>Real e Ilustre Colegio de Abogados de Zaragoza <a href="tel:976204220">976 204 220</a></li></li>
						<li>Colegio Oficial de Economistas de Aragón <a href="tel:976281356">976 281 356</a></li></li>
						<li>Ilustre Colegio Oficial de Titulados Mercantiles y Empresariales de Aragón <a href="tel:976446999">976 446 999</a></li></li>
						<li>Instituto de Censores Jurados de Cuentas. Agrupación Territorial 8º Aragón <a href="tel:976306001">976 306 001</a></li></li>
					</ul>			
					<p>Para más información sobre las unidades productivas que aparecen en la web contacte con <strong>Aragón Exterior</strong>:</p>
                    <ul>
	                    <li>Mail: <a href="mailto:invest@aragonexterior.es">invest@aragonexterior.es</a></li>
						<li>Tel: <a href="tel:976221571">976 221 571</a></li>
					</ul>	
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
