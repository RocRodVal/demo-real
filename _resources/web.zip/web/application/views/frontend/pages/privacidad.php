   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
                    <p>De conformidad con lo dispuesto en la Ley Orgánica 15/1999, de 13 de diciembre ,de Protección de Datos de Carácter Personal (LOPD), modificada por la Ley 62/2003, de 30 de diciembre, de medidas fiscales, administrativas y del orden social y en la sentencia 292/2000, de 30 de noviembre, recaída en el recurso de inconstitucionalidad 1463/2000 (BOE núm. 4, de 4 de enero del 2001), los datos suministrados por el usuario quedaran incorporados en un fichero automatizado y se recogerán a través de los mecanismos correspondientes, los cuales sólo contendrán los campos imprescindibles para poder prestar el servicio requerido por el usuario.</p>
					<p>Los datos de carácter personal serán tratados adecuadamente conforme a lo dispuesto en el Real Decreto 994/1999, de 11 de junio, por el que se aprueba el reglamento de medidas de seguridad de los ficheros automatizados que contengan datos de carácter personal, tomándose las medidas de seguridad necesarias para evitar su alteración, pérdida, tratamiento o acceso no autorizado por parte de terceros. Los datos de carácter personal sólo podrán ser cedidos, según lo dispuesto en el artículo 11 de la Ley Orgánica 15/1999 de 13 de diciembre, para el cumplimiento de fines directamente relacionados con las funciones legítimas del cedente y del cesionario con el previo consentimiento del afectado.</p>
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
