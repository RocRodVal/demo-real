<!-- Body -->
<h3><?=$name?></h3>
<p>
<strong>Año de fundación:</strong> <?=$year?><br />
<strong>Población y provincia:</strong> <?=$city?>, <?=$province_id?><br />
<strong>Situación concursal:</strong> <?=$situation_id?><br />
<strong>Empresas participadas en el mismo sector:</strong> <?=$same_sector?><br />
<strong>Empresas participadas en otros sectores:</strong> <?=$other_sector?><br />
<strong>Posibilidad de renunciar a la mejora:</strong> <?=$mejora?>
</p>
<p><strong>Descripción de la actividad:</strong></p>
<p><?=$description?></p>
<p>
<strong>Sector de actividad:</strong> <?=$sector_id?><br />
<strong>Código CNAE:</strong> <?=$cnae_id?><br />
<strong>En venta:</strong> <?=$sale_id?><br />
<strong>Zona de actuación:</strong> <?=$location_id?>
</p>
<p><strong>Productos/servicios principales:</strong></p>
<p><?=$products?></p>
<p>
<strong>Instalaciones:</strong> <?=$owner_id?><br />
<strong>M2 de superficie industrial:</strong> <?=$superficie?><br />
<strong>Sindicato representativo del Comité de Empresa:</strong> <?=$union_id?><br />
<strong>Volumen de negocio:</strong> <?=$volumen?><br />
<strong>Volumen de negocio 2012 (en euros):</strong> <?=$volumen_12?><br />
<strong>Volumen de negocio 2013 (en euros):</strong> <?=$volumen_13?><br />
<strong>Volumen de negocio 2014 (en euros):</strong> <?=$volumen_14?><br />
<strong>Número total de trabajadores:</strong> <?=$trabajadores?><br />
<strong>Número de puestos de trabajo directos (media anual):</strong> <?=$puestos_directos?><br />
<strong>Número de puestos de trabajo indirectos (media anual):</strong> <?=$puestos_indirectos?><br />
<strong>Volumen activo:</strong> <?=$volumen_activo?><br />
<strong>Volumen pasivo:</strong> <?=$volumen_pasivo?>
</p>
<p><strong>Certificaciones de calidad, patentes y homologaciones:</strong></p>
<p><?=$certs?></p>
<p><strong>Otros datos de interés:</strong></p>
<p><?=$more_info?></p>
