   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
                    <p>Si has olvidado tu contraseña, escribe a continuación tu correo de registro y recibirás un correo para que la restablezcas.</p>
                    <form action="<?=site_url('agente/recuperar');?>" method="post" class="content_auto form_login">
                    	<ul class="block">
                        	<li><label for="email">Email:</label> <input type="text" name="email" id="email" size="40" value="<?=$this->form_validation->set_value('email')?>" /></li>
                        </ul>                    
                        <p class="botonera"><input type="submit" class="submit" value="recuperar" /></p>       
                    </form>
                    <p>No te llegará ningún e-mail si la dirección que introduces no está registrada.</p>
                </div>   

                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
