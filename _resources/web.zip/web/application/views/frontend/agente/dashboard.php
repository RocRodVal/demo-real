   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
                    <p>Hola <strong><?=$email?></strong>. Aquí puede consultar todas las unidades productivas dadas de alta en nuestro portal.</p>
                    <p><div id="infoMessage"><h3><?php echo $message;?></h3></div></p>
                    <ul class="listado">
		         	<?php foreach ($unit as $unit_item): ?>
		         	<li>
		            	<a href="<?=site_url('agente/unidad_delete')?>/<?=$unit_item['company_id']?>" title="Borrar"><img src="<?=site_url('assets/img/icon-delete.png')?>" alt="Borrar" width="10" /></a> 
		            	<!--<a href="<?=site_url('agente/unidad_deactivate')?>/<?=$unit_item['company_id']?>"><strong>Desactivar</strong></a>--> 
		            	<a href="<?=site_url('home/unidad_agente')?>/<?=$unit_item['company_id']?>"><strong>Código registro #<?=$unit_item['company_id']?></strong></a>, <?=$unit_item['name']?>
		            </li>
		            <?php endforeach ?>    
		            </ul>                      
          			<p><a href="<?=site_url('agente/unidad_add')?>"><img src="<?=site_url('assets/img/icon-add.png')?>" alt="Añadir unidad" width="10" /> <strong>Añadir unidad</strong></a> | <a href="<?=site_url('agente/logout')?>"><strong>X Cerrar sesión</strong></a>.</p>             		
                </div>
                 
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
