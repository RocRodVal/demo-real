   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name_p?></h1>
                    <p>Para poder introducir empresas o unidades productivas en venta, debe tener una cuenta de usuario. Sus datos personales no serán visibles en la web pública. La Administración de la web le pondrá en contacto directamente con los interesados en las unidades productivas que añada.</p>
					<div id="infoMessage"><?php echo $message;?></div>	
                    <form action="<?=site_url('agente/registro');?>" method="post" class="content_auto form_login">
                    	<ul class="block">
	                        <li><label for="name">Nombre (*):</label> <input type="text" name="name" id="name" size="20" value="<?=$this->form_validation->set_value('name')?>" /></li>
                            <li><label for="surname">Apellidos (*):</label> <input type="text" name="surname" id="surname" size="50" value="<?=$this->form_validation->set_value('surname')?>" /></li>
                        	<li><label for="email">Email (*):</label> <input type="text" name="email" id="email" size="40" value="<?=$this->form_validation->set_value('email')?>" /></li>
                            <li><label for="password">Password (*):</label> <input type="password" name="password" id="password" size="10" /></li>
                            <li><label for="password_confirm">Repite password (*):</label> <input type="password" name="password_confirm" id="password_confirm" size="10" /></li>
                            <li><label for="phone">Teléfono (*):</label> <input type="text" name="phone" id="phone" size="40" value="<?=$this->form_validation->set_value('phone')?>" /></li>
                        </ul>                    
                        <h3>Datos laborales</h3>
                        <ul class="block">
	                        <li><label for="type_id">Tipo (*):</label>  
	                        <select id="type_id" name="type_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($type as $type_item): ?>
	                		<option <?=($this->form_validation->set_value('type_id')===$type_item['type_id']?'selected="selected"':'')?> value="<?=$type_item['type_id']?>"><?=$type_item['type']?></option>
	                		<?php endforeach ?>
	                		</select> 
                            </li>
                            <li><label for="company">Razón social (*):</label> <input type="text" name="company" id="company" size="20" value="<?=$this->form_validation->set_value('company')?>" /></li>
                            <li><label for="address">Dirección (*):</label> <textarea cols="40" rows="4" name="address" id="address"><?=$this->form_validation->set_value('address')?></textarea></li>
                            <li><input type="checkbox" name="agree" id="agree" /> <label for="agree" class="auto">Acepto las condiciones de uso de este site.</label></li>
                        </ul>           
                        <p>AREX garantiza que los datos contenidos en el registro serán utilizados de la forma y con las limitaciones y derechos que concede la Ley Orgánica 15/99, de 13 de Diciembre, de Protección de Datos de Carácter Personal.</p>
                        <p class="botonera"><input type="submit" class="submit" value="registrarse" /></p>
                    </form>    
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
