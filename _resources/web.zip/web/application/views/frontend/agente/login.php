   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
          			<p>Esta área está dirigida a administradores concursales y agentes que gestionen o dispongan de unidades productivas concursadas. Si no tienes cuenta de usuario, <a href="<?=site_url('agente/registro')?>"><strong>realiza aquí el registro</strong></a>.</p>
					<div id="infoMessage"><?php echo $message;?></div>
                    <form action="<?=site_url('agente');?>" method="post" class="content_auto form_login">
                    	<ul class="block">
                        	<li><label for="email">Email:</label> <input type="text" name="email" id="email" size="40" value="<?=$this->form_validation->set_value('email')?>" /></li>
                            <li><label for="password">Password:</label> <input type="password" name="password" id="password" size="40" value="<?=$this->form_validation->set_value('password')?>" /></li>
                        </ul>                    
                        <p class="botonera"><input type="submit" class="submit" value="entrar" /></p>  
                        <p>
                        	<a href="<?=site_url('agente/recuperar')?>">¿Olvidaste tu contraseña?</a>
                        	<a href="<?=site_url('agente/registro')?>">Crea una cuenta nueva</a>
                        </p>             
                    </form>               		
                </div>   

                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
