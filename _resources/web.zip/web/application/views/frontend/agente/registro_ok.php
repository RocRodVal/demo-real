   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name?></h1>
          			<p>Su usuario ha sido validado correctamente. A partir de este momento puede dar de alta sus unidades productivas en el portal.</p>      		
                </div>   
       
                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
