   		<!-- Body -->
        <div id="body" class="container_100">
        	<div class="container_auto">
                <div id="content" class="content_auto">
                    <h1><?=$name_p?></h1>
					<div id="infoMessage"><?php echo $message;?></div>	
                    <form action="<?=site_url('agente/unidad_add');?>" method="post" class="content_auto form_login">
                    	<ul class="block"> 
	                        <li><label for="name">Nombre de la empresa (*):</label> <input type="text" name="name" id="name" size="50" value="<?=$this->form_validation->set_value('name')?>" /></li>
	                        <li><label for="year">Año de fundación (*):</label> <input type="text" name="year" id="year" size="50" value="<?=$this->form_validation->set_value('year')?>" /></li>
	                        <li><label for="city">Población (*):</label> <input type="text" name="city" id="city" size="50" value="<?=$this->form_validation->set_value('city')?>" /></li>
	                        <li><label for="province_id">Provincia (*):</label>  
	                        <select id="province_id" name="province_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($province as $province_item): ?>
	                		<option <?=($this->form_validation->set_value('province_id')===$province_item['province_id']?'selected="selected"':'')?> value="<?=$province_item['province_id']?>"><?=$province_item['province']?></option>
	                		<?php endforeach ?>
	                		</select> 
                            </li>	                        
	                        <li><label for="situation_id">Situación concursal (*):</label>
	                        <p>
	                        	<strong>Preconcurso:</strong> paso previo a la declaración de concurso, que permite negociar con los acreedores antes del proceso judicial<br />
								<strong>Concurso:</strong> en proceso judicial  
	                        </p>	 
	                        <select id="situation_id" name="situation_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($situation as $situation_item): ?>
	                		<option <?=($this->form_validation->set_value('situation_id')===$situation_item['situation_id']?'selected="selected"':'')?> value="<?=$situation_item['situation_id']?>"><?=$situation_item['situation']?></option>
	                		<?php endforeach ?>
	                		</select> 
                            </li>
							<li><label for="same_sector">Empresas participadas en el mismo sector (*):</label>
							<input type="radio" name="same_sector" id="same_sector" value=1 <?=($this->form_validation->set_value('same_sector')==='1'?'checked':'')?> /> Sí<br /><br />
							<input type="radio" name="same_sector" id="same_sector" value=0 <?=($this->form_validation->set_value('same_sector')==='0'?'checked':'')?> /> No 
							</li> 							    				
							<li><label for="other_sector">Empresas participadas en otros sectores (*):</label>
							<input type="radio" name="other_sector" id="other_sector" value=1 <?=($this->form_validation->set_value('other_sector')==='1'?'checked':'')?> /> Sí<br /><br />
							<input type="radio" name="other_sector" id="other_sector" value=0 <?=($this->form_validation->set_value('other_sector')==='0'?'checked':'')?> /> No 
							</li>  
							<li><label for="mejora">Posibilidad de renunciar a la mejora (*):</label>
							<input type="radio" name="mejora" id="mejora" value=1 <?=($this->form_validation->set_value('mejora')==='1'?'checked':'')?> /> Sí<br /><br />
							<input type="radio" name="mejora" id="mejora" value=0 <?=($this->form_validation->set_value('mejora')==='0'?'checked':'')?> /> No 
							</li>   							  							           
							<li><label for="description">Descripción de la actividad (*):</label> <textarea cols="40" rows="4" name="description" id="description"><?=$this->form_validation->set_value('description')?></textarea></li>
	                        <li><label for="description_en">Descripción de la actividad (in English-opcional):</label> <textarea cols="40" rows="4" name="description_en" id="description_en"><?=$this->form_validation->set_value('description_en')?></textarea></li>
	                        <li><label for="sector_id">Sector (*):</label>  
	                        <select id="sector_id" name="sector_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($sector as $sector_item): ?>
	                		<option <?=($this->form_validation->set_value('sector_id')===$sector_item['sector_id']?'selected="selected"':'')?> value="<?=$sector_item['sector_id']?>"><?=$sector_item['sector']?></option>
	                		<?php endforeach ?>
	                		</select> 
                            </li>	
	                        <li><label for="cnae_id">Código CNAE:</label>  
	                        <select id="cnae_id" name="cnae_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($cnae as $cnae_item): ?>
	                		<option <?=($this->form_validation->set_value('cnae_id')===$cnae_item['cnae_id']?'selected="selected"':'')?> value="<?=$cnae_item['cnae_id']?>"><?=$cnae_item['cnae_cod']?> <?=$cnae_item['name']?></option>
	                		<?php endforeach ?>
	                		</select> 
                            </li>   
	                        <li><label for="sale_id">En venta (*):</label>
	                        <p>
	                        	<strong>Unidad productiva completa:</strong> venta de una empresa en su totalidad<br />
								<strong>Venta de unidad productiva:</strong> venta de una parte de la empresa que pueda ser desgajada de la misma  
	                        </p> 
	                        <select id="sale_id" name="sale_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($sale as $sale_item): ?>
	                		<option <?=($this->form_validation->set_value('sale_id')===$sale_item['sale_id']?'selected="selected"':'')?> value="<?=$sale_item['sale_id']?>"><?=$sale_item['sale']?></option>
	                		<?php endforeach ?>
	                		</select>                            
                            </li>     
	                        <li><label for="location_id">Localización (*):</label>  
	                        <select id="location_id" name="location_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($location as $location_item): ?>
	                		<option <?=($this->form_validation->set_value('location_id')===$location_item['location_id']?'selected="selected"':'')?> value="<?=$location_item['location_id']?>"><?=$location_item['location']?></option>
	                		<?php endforeach ?>
	                		</select> 
                            </li>                         
                            <li><label for="products">Productos/servicios principales (*):</label> <textarea cols="40" rows="4" name="products" id="products"><?=$this->form_validation->set_value('products')?></textarea></li>
                            <li><label for="products_en">Productos/servicios principales (in English-opcional):</label> <textarea cols="40" rows="4" name="products_en" id="products_en"><?=$this->form_validation->set_value('products_en')?></textarea></li>  
	                        <li><label for="owner_id">Instalaciones (*):</label>  
	                        <select id="owner_id" name="owner_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($owner as $owner_item): ?>
	                		<option <?=($this->form_validation->set_value('owner_id')===$owner_item['owner_id']?'selected="selected"':'')?> value="<?=$owner_item['owner_id']?>"><?=$owner_item['owner']?></option>
	                		<?php endforeach ?>
	                		</select> 
                            </li>
                            <li><label for="superficie">M2 de superficie industrial (*):</label> <input type="text" name="superficie" id="superficie" size="50" value="<?=$this->form_validation->set_value('superficie')?>" /></li>  
	                        <li><label for="union_id">Sindicato representativo del Comité de Empresa (*):</label>  
	                        <select id="union_id" name="union_id">
	               			<option value="">-- Seleccionar --</option>
	                		<?php foreach ($union as $union_item): ?>
	                		<option <?=($this->form_validation->set_value('union_id')===$union_item['union_id']?'selected="selected"':'')?> value="<?=$union_item['union_id']?>"><?=$union_item['union']?></option>
	                		<?php endforeach ?>
	                		</select> 
                            </li> 
                            <li><label for="volumen">Volumen de negocio (*):</label>  
					            <select id="volumen" name="volumen">
					            <option value="">-- Volumen de negocio --</option>
					            <option <?=($this->form_validation->set_value('volumen')==='Inferior a 1.000.000 €'?'selected="selected"':'')?> value="Inferior a 1.000.000 €">Inferior a 1.000.000 €</option>
					            <option <?=($this->form_validation->set_value('volumen')==='Superior a 1.000.000 €'?'selected="selected"':'')?> value="Superior a 1.000.000 €">Superior a 1.000.000 €</option>
					            </select>                            
                            </li>                            
                            <li><label for="volumen_12">Volumen de negocio 2012 (en euros) (*):</label> <input type="text" name="volumen_12" id="volumen_12" size="50" value="<?=$this->form_validation->set_value('volumen_12')?>" /></li>  
                            <li><label for="volumen_13">Volumen de negocio 2013 (en euros) (*):</label> <input type="text" name="volumen_13" id="volumen_13" size="50" value="<?=$this->form_validation->set_value('volumen_13')?>" /></li>
                            <li><label for="volumen_14">Volumen de negocio 2014 (en euros):</label> <input type="text" name="volumen_14" id="volumen_14" size="50" value="<?=$this->form_validation->set_value('volumen_14')?>" /></li>   
                            <li><label for="trabajadores">Número total de trabajadores (*):</label> <input type="text" name="trabajadores" id="trabajadores" size="50" value="<?=$this->form_validation->set_value('trabajadores')?>" /></li> 
                            <li><label for="puestos_directos">Número de puestos de trabajo directos (media anual) (*):</label> <input type="text" name="puestos_directos" id="puestos_directos" size="50" value="<?=$this->form_validation->set_value('puestos_directos')?>" /></li> 
                            <li><label for="puestos_indirectos">Número de puestos de trabajo indirectos (media anual) (*):</label> <input type="text" name="puestos_indirectos" id="puestos_indirectos" size="50" value="<?=$this->form_validation->set_value('puestos_indirectos')?>" /></li>
                            <li><label for="volumen_activo">Volumen activo (*):</label> <input type="text" name="volumen_activo" id="volumen_activo" size="50" value="<?=$this->form_validation->set_value('volumen_activo')?>" /></li> 
                            <li><label for="volumen_pasivo">Volumen pasivo (*):</label> <input type="text" name="volumen_pasivo" id="volumen_pasivo" size="50" value="<?=$this->form_validation->set_value('volumen_pasivo')?>" /></li>
                            <li><label for="certs">Certificaciones de calidad, patentes y homologaciones:</label> <textarea cols="40" rows="4" name="certs" id="certs"><?=$this->form_validation->set_value('certs')?></textarea></li> 
                            <li><label for="certs_en">Certificaciones de calidad, patentes y homologaciones (in English-opcional):</label> <textarea cols="40" rows="4" name="certs_en" id="certs_en"><?=$this->form_validation->set_value('certs_en')?></textarea></li> 
                            <li><label for="more_info">Otros datos de interés:</label> <textarea cols="40" rows="4" name="more_info" id="more_info"><?=$this->form_validation->set_value('more_info')?></textarea></li>                               
                            <li><label for="more_info_en">Otros datos de interés (in English-opcional):</label> <textarea cols="40" rows="4" name="more_info_en" id="more_info_en"><?=$this->form_validation->set_value('more_info_en')?></textarea></li>                                                                                                                                 							
  							<input type="hidden" name="pdf" id="pdf" value="<?=$this->form_validation->set_value('pdf')?>" />	                      
                        </ul>           
                        <p>AREX garantiza que los datos contenidos en el registro serán utilizados de la forma y con las limitaciones y derechos que concede la Ley Orgánica 15/99, de 13 de Diciembre, de Protección de Datos de Carácter Personal.</p>
                        <p class="botonera"><input type="submit" class="submit" value="añadir" /></p>
                    </form>    
                </div>   

                <div id="sidebar" class="content_auto">
                	<!-- banners -->
                	<p><a href="<?=site_url('pages/view/contacto')?>"><img src="<?=site_url('assets/img/sidebar-soporte-esp.png')?>" alt="Contacte con nosotros" width="189" /></a></p>
                </div>
            </div>
        </div>
