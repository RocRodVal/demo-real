<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->helper(array('dompdf','file','text'));
		$this->load->model('unidad');
	}

	public function index()
	{
		$data['title']        = 'Inicio';
		$data['sector_count'] = $this->unidad->count_sectors();
		$data['unit_count']   = $this->unidad->count_units();		
		$data['sale']         = $this->unidad->get_all_sales();
		$data['situation']    = $this->unidad->get_all_situations();
		$data['location']     = $this->unidad->get_all_locations();		
		$data['sector']       = $this->unidad->get_all_sectors();
		$data['cnae']         = $this->unidad->get_all_cnaes();
					
		$this->load->view('frontend/_header',$data);
		$this->load->view('frontend/home',$data);
		$this->load->view('frontend/_footer',$data);
	}
	
	public function eng()
	{
		$data['title']        = 'Home';
		$data['sector_count'] = $this->unidad->count_sectors();
		$data['unit_count']   = $this->unidad->count_units();
		$data['sale']         = $this->unidad->get_all_sales_eng();
		$data['situation']    = $this->unidad->get_all_situations_eng();
		$data['location']     = $this->unidad->get_all_locations_eng();
		$data['sector']       = $this->unidad->get_all_sectors_eng();
		$data['cnae']         = $this->unidad->get_all_cnaes();
			
		$this->load->view('frontend/eng/_header',$data);
		$this->load->view('frontend/eng/home',$data);
		$this->load->view('frontend/eng/_footer',$data);
	}	
	
	public function sector($sector_id)
	{
		$data['sector'] = $this->unidad->get_sector($sector_id);
	
		if (empty($data['sector']))
		{
			show_404();
		}
	
		$data['title']      = $data['sector']['sector'];
		$data['name']       = $data['sector']['sector'];
		$data['unit']       = $this->unidad->get_units_by_sector($sector_id);
		$data['unit_count'] = $this->unidad->count_units_by_sector($sector_id);
		$data['sale']       = $this->unidad->get_all_sales();
		$data['situation']  = $this->unidad->get_all_situations();
		$data['location']   = $this->unidad->get_all_locations();		
		$data['sector']     = $this->unidad->get_all_sectors();
		$data['cnae']       = $this->unidad->get_all_cnaes();
		
		if ($this->uri->segment(4) === 'pdf')
		{
			$header = $this->load->view('frontend/_pdf_header',$data,true);
			$body   = $this->load->view('frontend/pdf_sector',$data,true);
			$footer = $this->load->view('frontend/_pdf_footer',$data,true);
			$html   = $header.$body.$footer;
			pdf_create($html,'sector_'.$this->uri->segment(3));
		}
		else
		{
			$this->load->view('frontend/_header',$data);
			$this->load->view('frontend/sector',$data);
			$this->load->view('frontend/_footer',$data);		
		}
	}	

	public function sector_eng($sector_id)
	{
		$data['sector'] = $this->unidad->get_sector($sector_id);
	
		if (empty($data['sector']))
		{
			show_404();
		}
	
		$data['title']      = $data['sector']['sector_en'];
		$data['name']       = $data['sector']['sector_en'];
		$data['unit']       = $this->unidad->get_units_by_sector_eng($sector_id);
		$data['unit_count'] = $this->unidad->count_units_by_sector($sector_id);
		$data['sale']       = $this->unidad->get_all_sales_eng();
		$data['situation']  = $this->unidad->get_all_situations_eng();
		$data['location']   = $this->unidad->get_all_locations_eng();
		$data['sector']     = $this->unidad->get_all_sectors_eng();
		$data['cnae']       = $this->unidad->get_all_cnaes();
	
		if ($this->uri->segment(4) === 'pdf')
		{
			$header = $this->load->view('frontend/eng/_pdf_header',$data,true);
			$body   = $this->load->view('frontend/eng/pdf_sector',$data,true);
			$footer = $this->load->view('frontend/eng/_pdf_footer',$data,true);
			$html   = $header.$body.$footer;
			pdf_create($html,'sector_'.$this->uri->segment(3));
		}
		else
		{
			$this->load->view('frontend/eng/_header',$data);
			$this->load->view('frontend/eng/sector',$data);
			$this->load->view('frontend/eng/_footer',$data);
		}
	}	
	
	public function unidad_agente($company_id)
	{
		$data['unit'] = $this->unidad->get_unit_agent($company_id);
	
		if (empty($data['unit']))
		{
			show_404();
		}
	
		if (!empty($data['unit']['cnae_id']))
		{
			$data['cnae']     = $this->unidad->get_cnae($data['unit']['cnae_id']);
			$data['cnae_cod'] = $data['cnae']['cnae_cod'].' '.$data['cnae']['name'];
		}
		else
		{
			$data['cnae_cod'] = '---';
		}
	
		$data['title']              = 'Código registro #'. $data['unit']['company_id'];
		$data['name']               = 'Código registro #'. $data['unit']['company_id'];
		$data['year']               = $data['unit']['year'];
		$data['city']               = $data['unit']['city'];
		$data['province_id']        = $data['unit']['province'];
		$data['situation_id']       = $data['unit']['situation'];
		if ($data['unit']['same_sector']  == 1): $data['same_sector']='Sí'; else: $data['same_sector']='No'; endif;
		if ($data['unit']['other_sector'] == 1): $data['other_sector']='Sí'; else: $data['other_sector']='No'; endif;
		if ($data['unit']['mejora']       == 1): $data['mejora'] ='Sí'; else: $data['mejora']='No'; endif;
		$data['description']        = $data['unit']['description'];
		$data['sector_id']          = $data['unit']['sector'];
		$data['cnae_id']            = $data['cnae_cod'];
		$data['sale_id']            = $data['unit']['sale'];
		$data['location_id']        = $data['unit']['location'];
		$data['products']           = $data['unit']['products'];
		$data['owner_id']           = $data['unit']['owner'];
		$data['superficie']         = number_format($data['unit']['superficie'],0,',','.');
		$data['union_id']           = $data['unit']['sindicato'];
		$data['volumen']            = $data['unit']['volumen'];
		$data['volumen_12']         = number_format($data['unit']['volumen_12'],0,',','.');
		$data['volumen_13']         = number_format($data['unit']['volumen_13'],0,',','.');
		$data['volumen_14']         = number_format($data['unit']['volumen_14'],0,',','.');
		$data['trabajadores']       = number_format($data['unit']['trabajadores'],0,',','.');
		$data['puestos_directos']   = number_format($data['unit']['puestos_directos'],0,',','.');
		$data['puestos_indirectos'] = number_format($data['unit']['puestos_indirectos'],0,',','.');
		$data['volumen_activo']     = number_format($data['unit']['volumen_activo'],0,',','.');
		$data['volumen_pasivo']     = number_format($data['unit']['volumen_pasivo'],0,',','.');
		$data['volumen_pasivo']     = number_format($data['unit']['volumen_pasivo'],0,',','.');
		$data['certs']              = $data['unit']['certs'];
		$data['more_info']          = $data['unit']['more_info'];
		$data['sale']               = $this->unidad->get_all_sales();
		$data['situation']          = $this->unidad->get_all_situations();
		$data['location']           = $this->unidad->get_all_locations();
		$data['sector']             = $this->unidad->get_all_sectors();
		$data['cnae']               = $this->unidad->get_all_cnaes();
	
		if ($this->uri->segment(4) === 'pdf')
		{
			$header = $this->load->view('frontend/_pdf_header',$data,true);
			$body   = $this->load->view('frontend/pdf_unidad',$data,true);
			$footer = $this->load->view('frontend/_pdf_footer',$data,true);
			$html   = $header.$body.$footer;
			pdf_create($html,'unidad_'.$this->uri->segment(3));
		}
		else
		{
			$this->load->view('frontend/_header',$data);
			$this->load->view('frontend/unidad',$data);
			$this->load->view('frontend/_footer',$data);
		}
	}	
	
	public function unidad($company_id)
	{
		$data['unit'] = $this->unidad->get_unit($company_id);
	
		if (empty($data['unit']))
		{
			show_404();
		}

		if (!empty($data['unit']['cnae_id']))
		{
			$data['cnae']     = $this->unidad->get_cnae($data['unit']['cnae_id']);
			$data['cnae_cod'] = $data['cnae']['cnae_cod'].' '.$data['cnae']['name'];
		}
		else 
		{
			$data['cnae_cod'] = '---';
		}	
		
		$data['title']              = 'Código registro #'. $data['unit']['company_id'];
		$data['name']               = 'Código registro #'. $data['unit']['company_id'];
		$data['year']               = $data['unit']['year'];
		$data['city']               = $data['unit']['city'];
		$data['province_id']        = $data['unit']['province'];
		$data['situation_id']       = $data['unit']['situation'];
		if ($data['unit']['same_sector']  == 1): $data['same_sector']='Sí'; else: $data['same_sector']='No'; endif;
		if ($data['unit']['other_sector'] == 1): $data['other_sector']='Sí'; else: $data['other_sector']='No'; endif;
		if ($data['unit']['mejora']       == 1): $data['mejora'] ='Sí'; else: $data['mejora']='No'; endif;
		$data['description']        = $data['unit']['description'];
		$data['sector_id']          = $data['unit']['sector'];
		$data['cnae_id']            = $data['cnae_cod'];
		$data['sale_id']            = $data['unit']['sale'];
		$data['location_id']        = $data['unit']['location'];
		$data['products']           = $data['unit']['products'];
		$data['owner_id']           = $data['unit']['owner'];
		$data['superficie']         = number_format($data['unit']['superficie'],0,',','.');
		$data['union_id']           = $data['unit']['sindicato'];
		$data['volumen']            = $data['unit']['volumen'];
		$data['volumen_12']         = number_format($data['unit']['volumen_12'],0,',','.');
		$data['volumen_13']         = number_format($data['unit']['volumen_13'],0,',','.');
		$data['volumen_14']         = number_format($data['unit']['volumen_14'],0,',','.');
		$data['trabajadores']       = number_format($data['unit']['trabajadores'],0,',','.');
		$data['puestos_directos']   = number_format($data['unit']['puestos_directos'],0,',','.');
		$data['puestos_indirectos'] = number_format($data['unit']['puestos_indirectos'],0,',','.');
		$data['volumen_activo']     = number_format($data['unit']['volumen_activo'],0,',','.');
		$data['volumen_pasivo']     = number_format($data['unit']['volumen_pasivo'],0,',','.');
		$data['volumen_pasivo']     = number_format($data['unit']['volumen_pasivo'],0,',','.');
		$data['certs']              = $data['unit']['certs'];
		$data['more_info']          = $data['unit']['more_info'];
		$data['sale']               = $this->unidad->get_all_sales();
		$data['situation']          = $this->unidad->get_all_situations();
		$data['location']           = $this->unidad->get_all_locations();		
		$data['sector']             = $this->unidad->get_all_sectors();
		$data['cnae']               = $this->unidad->get_all_cnaes();
		
		if ($this->uri->segment(4) === 'pdf')
		{
			$header = $this->load->view('frontend/_pdf_header',$data,true);
			$body   = $this->load->view('frontend/pdf_unidad',$data,true);
			$footer = $this->load->view('frontend/_pdf_footer',$data,true);
			$html   = $header.$body.$footer;
			pdf_create($html,'unidad_'.$this->uri->segment(3));
		}
		else
		{
			$this->load->view('frontend/_header',$data);
			$this->load->view('frontend/unidad',$data);
			$this->load->view('frontend/_footer',$data);
		}		
	}	

	public function unidad_eng($company_id)
	{
		$data['unit'] = $this->unidad->get_unit_eng($company_id);
	
		if (empty($data['unit']))
		{
			show_404();
		}
	
		if (!empty($data['unit']['cnae_id']))
		{
			$data['cnae']     = $this->unidad->get_cnae($data['unit']['cnae_id']);
			$data['cnae_cod'] = $data['cnae']['cnae_cod'].' '.$data['cnae']['name'];
		}
		else
		{
			$data['cnae_cod'] = '---';
		}
	
		$data['title']              = 'Registration Code #'. $data['unit']['company_id'];
		$data['name']               = 'Registration Code #'. $data['unit']['company_id'];
		$data['year']               = $data['unit']['year'];
		$data['city']               = $data['unit']['city'];
		$data['province_id']        = $data['unit']['province'];
		$data['situation_id']       = $data['unit']['situation'];
		if ($data['unit']['same_sector']  == 1): $data['same_sector']='Yes'; else: $data['same_sector']='No'; endif;
		if ($data['unit']['other_sector'] == 1): $data['other_sector']='Yes'; else: $data['other_sector']='No'; endif;
		if ($data['unit']['mejora']       == 1): $data['mejora'] ='Yes'; else: $data['mejora']='No'; endif;
		$data['description']        = $data['unit']['description'];
		$data['description_en']     = $data['unit']['description_en'];
		$data['sector_id']          = $data['unit']['sector'];
		$data['cnae_id']            = $data['cnae_cod'];
		$data['sale_id']            = $data['unit']['sale'];
		$data['location_id']        = $data['unit']['location'];
		$data['products']           = $data['unit']['products'];
		$data['products_en']        = $data['unit']['products_en'];
		$data['owner_id']           = $data['unit']['owner'];
		$data['superficie']         = number_format($data['unit']['superficie'],0,'.',',');
		$data['union_id']           = $data['unit']['sindicato'];
		$data['volumen']            = $data['unit']['volumen'];
		$data['volumen_12']         = number_format($data['unit']['volumen_12'],0,'.',',');
		$data['volumen_13']         = number_format($data['unit']['volumen_13'],0,'.',',');
		$data['volumen_14']         = number_format($data['unit']['volumen_14'],0,'.',',');
		$data['trabajadores']       = number_format($data['unit']['trabajadores'],0,'.',',');
		$data['puestos_directos']   = number_format($data['unit']['puestos_directos'],0,'.',',');
		$data['puestos_indirectos'] = number_format($data['unit']['puestos_indirectos'],0,'.',',');
		$data['volumen_activo']     = number_format($data['unit']['volumen_activo'],0,'.',',');
		$data['volumen_pasivo']     = number_format($data['unit']['volumen_pasivo'],0,'.',',');
		$data['volumen_pasivo']     = number_format($data['unit']['volumen_pasivo'],0,'.',',');
		$data['certs']              = $data['unit']['certs'];
		$data['certs_en']           = $data['unit']['certs_en'];
		$data['more_info']          = $data['unit']['more_info'];
		$data['more_info_en']       = $data['unit']['more_info_en'];
		$data['sale']               = $this->unidad->get_all_sales_eng();
		$data['situation']          = $this->unidad->get_all_situations_eng();
		$data['location']           = $this->unidad->get_all_locations_eng();
		$data['sector']             = $this->unidad->get_all_sectors_eng();
		$data['cnae']               = $this->unidad->get_all_cnaes();
	
		if ($this->uri->segment(4) === 'pdf')
		{
			$header = $this->load->view('frontend/eng/_pdf_header',$data,true);
			$body   = $this->load->view('frontend/eng/pdf_unidad',$data,true);
			$footer = $this->load->view('frontend/eng/_pdf_footer',$data,true);
			$html   = $header.$body.$footer;
			pdf_create($html,'unidad_'.$this->uri->segment(3));
		}
		else
		{
			$this->load->view('frontend/eng/_header',$data);
			$this->load->view('frontend/eng/unidad',$data);
			$this->load->view('frontend/eng/_footer',$data);
		}
	}	
	
	public function buscar()
	{
		if ($this->uri->segment(3) === 'pdf')
		{
			$sale_id      = $this->uri->segment(4);
			$situation_id = $this->uri->segment(5);
			$location_id  = $this->uri->segment(6);
			$volumen      = $this->uri->segment(7);
			$sector_id    = $this->uri->segment(8);
			$cnae_id      = $this->uri->segment(9);
			$data['unit'] = $this->unidad->buscar($sale_id,$situation_id,$location_id,$volumen,$sector_id,$cnae_id);
		}
		else
		{
			$sale_id      = $this->input->post('sale_id');
			$situation_id = $this->input->post('situation_id');
			$location_id  = $this->input->post('location_id');
			$volumen      = $this->input->post('volumen');
			$sector_id    = $this->input->post('sector_id');
			$cnae_id      = $this->input->post('cnae_id');
			$data['unit'] = $this->unidad->buscar($sale_id,$situation_id,$location_id,$volumen,$sector_id,$cnae_id);
		}		
		

		
		$data['title']         = 'Resultados de la búsqueda';
		$data['name']          = 'Resultados de la búsqueda';
		$data['sale_sel']      = $sale_id;
		$data['situation_sel'] = $situation_id;
		$data['location_sel']  = $location_id;
		$data['volumen_sel']   = $volumen;
		$data['sector_sel']    = $sector_id;	
		$data['cnae_sel']      = $cnae_id;
		$data['sale']          = $this->unidad->get_all_sales();
		$data['situation']     = $this->unidad->get_all_situations();
		$data['location']      = $this->unidad->get_all_locations();		
		$data['sector']        = $this->unidad->get_all_sectors();
		$data['cnae']          = $this->unidad->get_all_cnaes();
	
		if ($this->uri->segment(3) === 'pdf')
		{
			$header = $this->load->view('frontend/_pdf_header',$data,true);
			$body   = $this->load->view('frontend/pdf_buscar',$data,true);
			$footer = $this->load->view('frontend/_pdf_footer',$data,true);
			$html   = $header.$body.$footer;
			pdf_create($html,'resultados_busqueda_'.rand());
		}
		else
		{
			$this->load->view('frontend/_header',$data);
			$this->load->view('frontend/buscar',$data);
			$this->load->view('frontend/_footer',$data);
		}		
	}	
	
	public function buscar_eng()
	{
		if ($this->uri->segment(3) === 'pdf')
		{
			$sale_id      = $this->uri->segment(4);
			$situation_id = $this->uri->segment(5);
			$location_id  = $this->uri->segment(6);
			$volumen      = $this->uri->segment(7);
			$sector_id    = $this->uri->segment(8);
			$cnae_id      = $this->uri->segment(9);
			$data['unit'] = $this->unidad->buscar_eng($sale_id,$situation_id,$location_id,$volumen,$sector_id,$cnae_id);
		}
		else
		{
			$sale_id      = $this->input->post('sale_id');
			$situation_id = $this->input->post('situation_id');
			$location_id  = $this->input->post('location_id');
			$volumen      = $this->input->post('volumen');
			$sector_id    = $this->input->post('sector_id');
			$cnae_id      = $this->input->post('cnae_id');
			$data['unit'] = $this->unidad->buscar_eng($sale_id,$situation_id,$location_id,$volumen,$sector_id,$cnae_id);
		}
	
	
	
		$data['title']         = 'Search results';
		$data['name']          = 'Search results';
		$data['sale_sel']      = $sale_id;
		$data['situation_sel'] = $situation_id;
		$data['location_sel']  = $location_id;
		$data['volumen_sel']   = $volumen;
		$data['sector_sel']    = $sector_id;
		$data['cnae_sel']      = $cnae_id;
		$data['sale']          = $this->unidad->get_all_sales_eng();
		$data['situation']     = $this->unidad->get_all_situations_eng();
		$data['location']      = $this->unidad->get_all_locations_eng();
		$data['sector']        = $this->unidad->get_all_sectors_eng();
		$data['cnae']          = $this->unidad->get_all_cnaes();
	
		if ($this->uri->segment(3) === 'pdf')
		{
			$header = $this->load->view('frontend/eng/_pdf_header',$data,true);
			$body   = $this->load->view('frontend/eng/pdf_buscar',$data,true);
			$footer = $this->load->view('frontend/eng/_pdf_footer',$data,true);
			$html   = $header.$body.$footer;
			pdf_create($html,'resultados_busqueda_'.rand());
		}
		else
		{
			$this->load->view('frontend/eng/_header',$data);
			$this->load->view('frontend/eng/buscar',$data);
			$this->load->view('frontend/eng/_footer',$data);
		}
	}	

}