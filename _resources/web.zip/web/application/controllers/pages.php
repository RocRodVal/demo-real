<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages extends CI_Controller {

	function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper(array('url','language'));
	}

	public function view($page = 'home')
	{
		if ( ! file_exists('application/views/frontend/pages/'.$page.'.php'))
		{
			// Whoops, we don't have a page for that!
			show_404();
		}

		switch ($page)
		{
			case 'contacto':
				$title = 'Contacte con nosotros';
				$name  = 'Contacte con nosotros';
				break;
			case 'legal':
				$title = 'Aviso legal';
				$name  = 'Aviso legal';
				break;							
			case 'privacidad':
				$title = 'Política de privacidad';
				$name  = 'Política de privacidad';
				break;						
			default:
				$title = 'Portal de venta de unidades productivas';
				$name  = 'Portal de venta de unidades productivas';
		}

		$data['title'] = $title;
		$data['name']  = $name;

		$this->load->view('frontend/_header',$data);
		$this->load->view('frontend/pages/'.$page, $data);
		$this->load->view('frontend/_footer',$data);
	}

	public function eng($page = 'home')
	{
		if ( ! file_exists('application/views/frontend/eng/pages/'.$page.'.php'))
		{
			// Whoops, we don't have a page for that!
			show_404();
		}
	
		switch ($page)
		{
			case 'contacto':
				$title = 'Contact us';
				$name  = 'Contact us';
				break;
			case 'legal':
				$title = 'Legal Notice';
				$name  = 'Legal Notice';
				break;
			case 'privacidad':
				$title = 'Privacy Policy';
				$name  = 'Privacy Policy';
				break;
			default:
				$title = 'Production Unit Sale Portal';
				$name  = 'Production Unit Sale Portal';
		}
	
		$data['title'] = $title;
		$data['name']  = $name;
	
		$this->load->view('frontend/eng/_header',$data);
		$this->load->view('frontend/eng/pages/'.$page, $data);
		$this->load->view('frontend/eng/_footer',$data);
	}	
	
}