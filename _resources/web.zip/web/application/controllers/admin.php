<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct()
	{
		parent::__construct();

		$this->load->library(array('grocery_CRUD','ajax_grocery_CRUD','ion_auth'));
		$this->load->database();

		if (!$this->ion_auth->logged_in())
		{
			redirect('auth/login');
		}		
	}

	
	function _admin_output($output = null)
	{
		$this->load->view('backend/header', $output);
		$this->load->view('backend/navbar', $output);
		$this->load->view('backend/content', $output);
		$this->load->view('backend/footer');
	}

	
	function admin()
	{
		$output = $this->grocery_crud->render();
		$this->_admin_output($output);
	}

	
	function index()
	{
		$this->_admin_output((object)array('output' => '', 'js_files' => array() , 'css_files' => array()));
	}

	
	/* Agent */
	function agent()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('agent');
			$crud->set_subject('agente');
			$crud->change_field_type('password','password');
			$crud->set_relation('type_id','type','type');
			$crud->set_rules('email', 'Email', 'valid_email');
			$crud->required_fields('name','surname','type_id','email','password','phone','company','address','status');
			$crud->columns('name','surname','type_id','email','status');
			
			$crud->display_as('name','Nombre')
			->display_as('surname','Apellidos')
			->display_as('type_id','Tipo')
			->display_as('email','Email')
			->display_as('password','Password')
			->display_as('phone','Teléfono')
			->display_as('company','Razón social')
			->display_as('address','Dirección profesional')
			->display_as('created','Fecha alta')
			->display_as('last_login','Última conexión')
			->display_as('status','Activo');			
			
			$crud->display_as('agent','Agente');
	
			$crud->order_by('status','asc');
			$crud->order_by('created','desc');
			$output = $crud->render();
			$output->title = 'Gestión agente';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}	
	

	/* Company */
	function company()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('company');
			$crud->set_subject('unidad productiva');
			$crud->set_relation('province_id','province','province');
			$crud->set_relation('situation_id','situation','situation');
			$crud->set_relation('sector_id','sector','sector');
			$crud->set_relation('cnae_id','cnae','{cnae_cod} {name}');
			$crud->set_relation('sale_id','sale','sale');
			$crud->set_relation('location_id','location','location');
			$crud->set_relation('owner_id','owner','owner');
			$crud->set_relation('union_id','union','union');
			$crud->set_relation('agent_id','agent','{name} {surname}');
			$crud->set_field_upload('pdf',UPLOAD_PATH.'company');
			$crud->required_fields('year','name','city','province_id','situation_id','same_sector','other_sector','mejora','description','sector_id','sale_id','location_id','products','owner_id','superficie','union_id','volumen','volumen_12','volumen_13','trabajadores','puestos_directos','puestos_indirectos','volumen_activo','volumen_pasivo','agent_id','status');
			$crud->columns('company_id','name','sale_id','situation_id','sector_id','agent_id','status');
				
	
			$crud->display_as('company_id','Código registro')
			->display_as('year','Año de fundación')
			->display_as('name','Nombre de la empresa')
			->display_as('city','Población')
			->display_as('province_id','Provincia')
			->display_as('situation_id','Situación concursal')
			->display_as('same_sector','Empresas participadas en el mismo sector')
			->display_as('other_sector','Empresas participadas en otros sectores')
			->display_as('mejora','Posibilidad de renunciar a la mejora')
			->display_as('description','Descripción de la actividad [ES]')
			->display_as('description_en','Descripción de la actividad [EN]')
			->display_as('sector_id','Sector')
			->display_as('cnae_id','Código CNAE')
			->display_as('sale_id','En venta')
			->display_as('location_id','Localización')
			->display_as('products','Productos/servicios principales [ES]')
			->display_as('products_en','Productos/servicios principales [EN]')
			->display_as('owner_id','Instalaciones')
			->display_as('superficie','M2 de superficie industrial')
			->display_as('union_id','Sindicato representativo del Comité de Empresa')
			->display_as('volumen','Volumen de negocio')
			->display_as('volumen_12','Volumen de negocio 2012 (en euros)')
			->display_as('volumen_13','Volumen de negocio 2013 (en euros)')
			->display_as('volumen_14','Volumen de negocio 2014 (en euros)')
			->display_as('trabajadores','Número total de trabajadores')
			->display_as('puestos_directos','Número de puestos de trabajo directos (media anual)')
			->display_as('puestos_indirectos','Número de puestos de trabajo indirectos (media anual)')
			->display_as('volumen_activo','Volumen activo')
			->display_as('volumen_pasivo','Volumen pasivo')
			->display_as('certs','Certificaciones de calidad, patentes y homologaciones [ES]')
			->display_as('certs_en','Certificaciones de calidad, patentes y homologaciones [EN]')
			->display_as('more_info','Otros datos de interés [ES]')
			->display_as('more_info_en','Otros datos de interés [EN]')
			->display_as('pdf','PDF')
			->display_as('agent_id','Agente')			
			->display_as('status','Activo');
	
			$output = $crud->render();
			$output->title = 'Gestión unidad productiva';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}	
	
	
	/* Location */
	function location()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('location');
			$crud->set_subject('ámbito de negocio');
			$crud->required_fields('location','location_en');
			$crud->columns('location');
	
			$crud->display_as('location','Ámbito de negocio [ES]')
			->display_as('location_en','Ámbito de negocio [EN]');
	
			$output = $crud->render();
			$output->title = 'Gestión ámbito de negocio';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}	

	
	/* Owner */
	function owner()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('owner');
			$crud->set_subject('tipo de propiedad');
			$crud->required_fields('owner','owner_en');
			$crud->columns('owner');
	
			$crud->display_as('owner','Tipo de propiedad [ES]')
			->display_as('owner_en','Tipo de propiedad [EN]');
	
			$output = $crud->render();
			$output->title = 'Gestión tipo de propiedad';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}	

	
	/* Sale */
	function sale()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('sale');
			$crud->set_subject('tipo de venta');
			$crud->required_fields('sale','sale_en');
			$crud->columns('sale');
	
			$crud->display_as('sale','Tipo de venta [ES]')
			->display_as('sale_en','Tipo de venta [EN]');
	
			$output = $crud->render();
			$output->title = 'Gestión tipo de venta';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}	
	
	
	/* Sector */
	function sector()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('sector');
			$crud->set_subject('sector de actividad');
			$crud->set_field_upload('picture',UPLOAD_PATH.'sector');
			$crud->required_fields('sector','sector_en');
			$crud->columns('sector');
	
			$crud->display_as('sector','Sector de actividad [ES]')
			->display_as('sector_en','Sector de actividad [EN]')
			->display_as('picture','Foto');
	
			$output = $crud->render();
			$output->title = 'Gestión sector de actividad';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}	

	
	/* Situation */
	function situation()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('situation');
			$crud->set_subject('situación concursal');
			$crud->required_fields('situation','situation_en');
			$crud->columns('situation');
	
			$crud->display_as('situation','Situación concursal [ES]')
			->display_as('situation_en','Situación concursal [EN]');
	
			$output = $crud->render();
			$output->title = 'Gestión situación concursal';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}	

	
	/* Type */
	function type()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('type');
			$crud->set_subject('tipo de agente');
			$crud->required_fields('type');
			$crud->columns('type');
	
			$crud->display_as('type','Tipo de agente');
	
			$output = $crud->render();
			$output->title = 'Gestión tipo de agente';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	
	
	/* Union */
	function union()
	{
		try{
			$crud = new grocery_CRUD();
	
			$crud->set_theme('datatables');
			$crud->set_table('union');
			$crud->set_subject('sindicato');
			$crud->required_fields('union');
			$crud->columns('union');
	
			$crud->display_as('union','Sindicato');
	
			$output = $crud->render();
			$output->title = 'Gestión sindicato';
			$this->_admin_output($output);
	
		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
		

	/* Funciones */
	function encrypt_password_callback($post_array, $primary_key = null)
	{
		$this->load->library('encrypt');
		$post_array['password'] = $this->encrypt->encode($post_array['password']);
		return $post_array;
	}
	
	function decrypt_password_callback($value)
	{
		$this->load->library('encrypt');
		$decrypted_password = $this->encrypt->decode($value);
		return "<input type='password' name='password' value='$decrypted_password' />";
	}
	
}
/* End of file admin.php */
/* Location: ./application/controllers/admin.php */