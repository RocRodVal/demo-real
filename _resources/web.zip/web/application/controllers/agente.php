<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Agente extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();

		$this->load->model('agente_model');
		$this->load->model('unidad');
		$this->load->library(array('encrypt','email','form_validation','session'));
		$this->load->helper('text');
    	$this->lang->load('site');    
	}
	

	public function index()
	{	
		$this->form_validation->set_rules('email','email','required|valid_email|xss_clean');
		$this->form_validation->set_rules('password','password','required|xss_clean');
	
		if ($this->form_validation->run() == true)
		{
			$data = array(
					'email' 	=> strtolower($this->input->post('email')),
					'password' 	=> $this->input->post('password'),
			);
		}
		
		if ($this->form_validation->run() == true && $this->agente_model->login($data))
		{
			redirect('agente/dashboard');
		}
		else
		{
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->session->flashdata('message')));
				
			$data['title'] = 'Login de agente';
			$data['name']  = 'Login de agente';

			$this->load->view('frontend/_header',$data);
			$this->load->view('frontend/agente/login',$this->data);
			$this->load->view('frontend/_footer',$data);
		}
	}	

	public function recuperar()
	{
		$data['title'] = 'Recuperar contraseña';
		$data['name']  = 'Recuperar contraseña';
	
		$this->load->view('frontend/_header',$data);
		$this->load->view('frontend/agente/recuperar',$data);
		$this->load->view('frontend/_footer',$data);

	}	

	
	public function registro()
	{
		$this->form_validation->set_rules('name','nombre','required|xss_clean');
		$this->form_validation->set_rules('surname','apellidos','required|xss_clean');
		$this->form_validation->set_rules('email','email','required|valid_email|is_unique[agent.email]');
		$this->form_validation->set_rules('password','password','required|matches[password_confirm]');
		$this->form_validation->set_rules('password_confirm','confirmar password','required');
		$this->form_validation->set_rules('phone','teléfono','required|xss_clean');
		$this->form_validation->set_rules('type_id','tipo','required|xss_clean');		
		$this->form_validation->set_rules('company','razón social','required|xss_clean');
		$this->form_validation->set_rules('address','dirección','required|xss_clean');
		$this->form_validation->set_rules('agree','condiciones legales','required|xss_clean');
		
		if ($this->form_validation->run() == true)
		{
			$data = array(
				'name'    	=> $this->input->post('name'),
				'surname'   => $this->input->post('surname'),								
				'email' 	=> strtolower($this->input->post('email')),
				'password' 	=> $this->input->post('password'),
				'phone'		=> $this->input->post('phone'),
				'type_id'   => $this->input->post('type_id'),					
				'company' 	=> $this->input->post('company'),
				'address'  	=> $this->input->post('address'),
				'created'	=> date('Y-m-d H:i:s'),
				'status'	=> 1,
			);
		}
		if ($this->form_validation->run() == true && $this->agente_model->registro($data))
		{ 
			$message_admin  = 'Se ha registrado un nuevo agente.'."\r\n\r\n";
			$message_admin .= 'El email de registro es '.strtolower($this->input->post('email')).' y está ha validado. En http://www.investinaragon.com/buscador/admin/ podrá revisar dicho usuario.'."\r\n\r\n";
			$message_admin .= 'Atentamente,'."\r\n";
			$message_admin .= 'Portal de Unidades Productivas'."\r\n\r\n";
			$message_admin .= 'http://www.investinaragon.com/buscador/'."\r\n";
			
			$this->email->from('no-reply@aragonexterior.es', 'Aragón Exterior – AREX');
			$this->email->to('invest@aragonexterior.es,colegioaragon@economistas.org');
			$this->email->bcc('gustavo.zapico@bittia.com');
			$this->email->subject('Portal de venta de unidades productivas');
			$this->email->message($message_admin);
			$this->email->send();
			
			$this->email->clear();
			
			/*
			$message  = 'Gracias por registrarse en nuestra web.'."\r\n\r\n";
			$message .= 'Como Agente Registrado podrá añadir oportunidades de compraventa de unidades productivas, ya sea usted administrador concursal de la misma u otro gestor vinculado a empresas en proceso de venta.'."\r\n\r\n";
			$message .= 'En breve recibirá un correo validando su inscripción para que pueda comenzar a subir a la web unidades productivas en venta. Si durante el proceso tuviera cualquier problema, no dude en ponerse en contacto con nosotros.'."\r\n\r\n";
			$message .= 'Atentamente,'."\r\n";
			$message .= 'Portal de Unidades Productivas'."\r\n\r\n";
			$message .= 'http://www.investinaragon.com/buscador/'."\r\n";
			
			$this->email->from('no-reply@aragonexterior.es', 'Aragón Exterior – AREX');
			$this->email->to(strtolower($this->input->post('email')));
			$this->email->cc('gustavo.zapico@bittia.com');
			$this->email->subject('Portal de venta de unidades productivas');
			$this->email->message($message);
			$this->email->send();
			*/			
			
			redirect('agente/registro_ok');	
		}
		else
		{ 
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->session->flashdata('message')));
			
			$data['title']  = 'Registro de agente';
			$data['name_p'] = 'Registro de agente';
			$data['type']   = $this->agente_model->types();
			
			$this->load->view('frontend/_header',$data);
			$this->load->view('frontend/agente/registro',$this->data);
			$this->load->view('frontend/_footer',$data);
		}
	}

	public function registro_ok()
	{
			$data['title'] = 'Registro de agente';
			$data['name']  = 'Registro de agente';
		
			$this->load->view('frontend/_header',$data);
			$this->load->view('frontend/agente/registro_ok',$data);
			$this->load->view('frontend/_footer',$data);		
	}
	
	
	public function unidad_ok()
	{
		$data['title'] = 'Dashboard de agente - Añadir unidad';
		$data['name']  = 'Dashboard de agente - Añadir unidad';
			
		$this->load->view('frontend/_header',$data);
		$this->load->view('frontend/agente/unidad_ok',$data);
		$this->load->view('frontend/_footer',$data);
	}	

	public function dashboard()
	{
			$data['title'] = 'Dashboard de agente';
			$data['name']  = 'Dashboard de agente';

		if($this->session->userdata('logged_in'))
		{
			$session_data     = $this->session->userdata('logged_in');
			$data['email']    = $this->session->userdata('email');
			$data['agent_id'] = $this->session->userdata('agent_id');
			
			$data['message']  = $this->session->flashdata('message');
			
			$data['unit']     = $this->unidad->get_units_by_agent($data['agent_id']);
			
			$this->load->view('frontend/_header',$data);
			$this->load->view('frontend/agente/dashboard',$data);
			$this->load->view('frontend/_footer',$data);
		}
		else
		{
			redirect('agente','refresh');
		}	
	}

	public function unidad_add()
	{

		if($this->session->userdata('logged_in'))
		{	
			$session_data     = $this->session->userdata('logged_in');
			$data['email']    = $this->session->userdata('email');
			$data['agent_id'] = $this->session->userdata('agent_id');			
			
			$this->form_validation->set_rules('name','nombre de la empresa','required|xss_clean');
			$this->form_validation->set_rules('year','año de fundación','required|xss_clean');
			$this->form_validation->set_rules('city','población','required|xss_clean');
			$this->form_validation->set_rules('province_id','provincia','required|xss_clean');
			$this->form_validation->set_rules('situation_id','situación concursal','required|xss_clean');
			$this->form_validation->set_rules('same_sector','empresas participadas en el mismo sector','required|xss_clean');
			$this->form_validation->set_rules('other_sector','empresas participadas en otros sectores','required|xss_clean');
			$this->form_validation->set_rules('mejora','posibilidad de renunciar a la mejora','required|xss_clean');
			$this->form_validation->set_rules('description','descripción de la actividad (es)','required|xss_clean');
			$this->form_validation->set_rules('description_en','descripción de la actividad (en)','xss_clean');
			$this->form_validation->set_rules('sector_id','sector','required|xss_clean');
			$this->form_validation->set_rules('cnae_id','código CNAE','xss_clean');
			$this->form_validation->set_rules('sale_id','en venta','required|xss_clean');
			$this->form_validation->set_rules('location_id','localización','required|xss_clean');
			$this->form_validation->set_rules('products','productos/servicios principales (es)','required|xss_clean');
			$this->form_validation->set_rules('products_en','productos/servicios principales (en)','xss_clean');
			$this->form_validation->set_rules('owner_id','instalaciones','required|xss_clean');
			$this->form_validation->set_rules('superficie','M2 de superficie industrial','required|xss_clean|integer');
			$this->form_validation->set_rules('union_id','sindicato representativo del Comité de Empresa','required|xss_clean');
			$this->form_validation->set_rules('volumen','volumen de negocio','required|xss_clean');
			$this->form_validation->set_rules('volumen_12','volumen de negocio 2012 (en euros)','required|xss_clean|integer');
			$this->form_validation->set_rules('volumen_13','volumen de negocio 2013 (en euros)','required|xss_clean|integer');
			$this->form_validation->set_rules('volumen_14','volumen de negocio 2014 (en euros)','xss_clean|integer');
			$this->form_validation->set_rules('trabajadores','número total de trabajadores','required|xss_clean|integer');
			$this->form_validation->set_rules('puestos_directos','número de puestos de trabajo directos (media anual)','required|xss_clean|integer');
			$this->form_validation->set_rules('puestos_indirectos','número de puestos de trabajo indirectos (media anual)','required|xss_clean|integer');
			$this->form_validation->set_rules('volumen_activo','volumen activo','required|xss_clean|integer');
			$this->form_validation->set_rules('volumen_pasivo','volumen pasivo','required|xss_clean|integer');
			$this->form_validation->set_rules('certs','certificaciones de calidad, patentes y homologaciones (es)','xss_clean');
			$this->form_validation->set_rules('certs_en','certificaciones de calidad, patentes y homologaciones (en)','xss_clean');
			$this->form_validation->set_rules('more_info','otros datos de interés (es)','xss_clean');
			$this->form_validation->set_rules('more_info_en','otros datos de interés (en)','xss_clean');
			$this->form_validation->set_rules('pdf','PDF','xss_clean');
		
			if ($this->form_validation->run() == true)
			{
				$data = array(
						'name'    			 => $this->input->post('name'),
						'year'    			 => $this->input->post('year'),
						'city'    			 => $this->input->post('city'),
						'province_id'    	 => $this->input->post('province_id'),
						'situation_id'    	 => $this->input->post('situation_id'),
						'same_sector'    	 => $this->input->post('same_sector'),
						'other_sector'    	 => $this->input->post('other_sector'),
						'mejora'    		 => $this->input->post('mejora'),						
						'description'    	 => $this->input->post('description'),
						'description_en'     => $this->input->post('description_en'),
						'sector_id'    		 => $this->input->post('sector_id'),
						'cnae_id'    		 => $this->input->post('cnae_id'),
						'sale_id'    		 => $this->input->post('sale_id'),
						'location_id'    	 => $this->input->post('location_id'),
						'products'    		 => $this->input->post('products'),
						'products_en'  		 => $this->input->post('products_en'),
						'owner_id'    		 => $this->input->post('owner_id'),
						'superficie'    	 => $this->input->post('superficie'),	
						'union_id'   		 => $this->input->post('union_id'),
						'volumen' 	         => $this->input->post('volumen'),
						'volumen_12' 	     => $this->input->post('volumen_12'),
						'volumen_13' 	     => $this->input->post('volumen_13'),
						'volumen_14' 	     => $this->input->post('volumen_14'),
						'trabajadores'		 => $this->input->post('trabajadores'),
						'puestos_directos'   => $this->input->post('puestos_directos'),
						'puestos_indirectos' => $this->input->post('puestos_indirectos'),
						'volumen_activo'  	 => $this->input->post('volumen_activo'),
						'volumen_pasivo'  	 => $this->input->post('volumen_pasivo'),
						'certs'  	         => $this->input->post('certs'),
						'certs_en'  	     => $this->input->post('certs_en'),
						'more_info'          => $this->input->post('more_info'),
						'more_info_en'       => $this->input->post('more_info_en'),
						'pdf'                => $this->input->post('pdf'),
						'agent_id'	         => $this->session->userdata('agent_id'),
						'status'	         => 1
				);
			}
			if ($this->form_validation->run() == true && $this->agente_model->registro_unidad($data))
			{
				redirect('agente/unidad_ok');
			}
			else
			{
				$this->data['message'] = (validation_errors() ? validation_errors() : ($this->session->flashdata('message')));
					
				$data['title']     = 'Dashboard de agente - Añadir unidad';
				$data['name_p']    = 'Dashboard de agente - Añadir unidad';
				
				$data['province']  = $this->unidad->get_all_provinces();
				$data['situation'] = $this->unidad->get_all_situations();
				$data['sector']    = $this->unidad->get_all_sectors();
				$data['cnae']      = $this->unidad->get_all_cnaes();
				$data['sale']      = $this->unidad->get_all_sales();
				$data['location']  = $this->unidad->get_all_locations();
				$data['owner']     = $this->unidad->get_all_owners();
				$data['union']     = $this->unidad->get_all_unions();				
					
				$this->load->view('frontend/_header',$data);
				$this->load->view('frontend/agente/unidad_add',$this->data);
				$this->load->view('frontend/_footer',$data);
			}		
		}
		else
		{
			redirect('agente','refresh');
		}		
	}	
	
	public function unidad_delete($company_id) 
	{
		$this->agente_model->unidad_delete($company_id);
		$this->session->set_flashdata('message', '<p>¡Unidad borrada!</p>');
	
		redirect('agente/dashboard');
	}
		
	public function logout()
	{
		$this->session->unset_userdata('logged_in');
		redirect('home','refresh');
	}	
}